clear;close all;clc;
load('FT_EXCESS_DEATHS.mat')
load('DATA.mat')

%% ITALY
figure;
subplot(2,3,1)
hold all;
plot(ExcessDeaths_IT.date(1:51),ExcessDeaths_IT.DeathsRecorded(1:51))
plot(ExcessDeaths_IT.date(52:103),ExcessDeaths_IT.DeathsRecorded(52:103))
plot(ExcessDeaths_IT.date(104:154),ExcessDeaths_IT.DeathsRecorded(104:154))
plot(ExcessDeaths_IT.date(155:205),ExcessDeaths_IT.DeathsRecorded(155:205))
plot(ExcessDeaths_IT.date(206:256),ExcessDeaths_IT.DeathsRecorded(206:256))
plot(ExcessDeaths_IT.date(257:273),ExcessDeaths_IT.DeathsRecorded(257:273))
grid on;box on;
xlabel('Date')
ylabel('Deaths per Week')
title('Raw Data (ITALY) from Financial Times Github')

subplot(2,3,2)
hold all;
plot(ExcessDeaths_IT.DeathsRecorded(1:51))
plot(ExcessDeaths_IT.DeathsRecorded(52:103))
plot(ExcessDeaths_IT.DeathsRecorded(104:154))
plot(ExcessDeaths_IT.DeathsRecorded(155:205))
plot(ExcessDeaths_IT.DeathsRecorded(206:256))
plot(ExcessDeaths_IT.DeathsRecorded(257:273))
plot(ExcessDeaths_IT.DeathsExpected(1:51),'LineWidth',2)
grid on;box on;
legend('2015','2016','2017','2018','2019','2020','Expected (Median 2015-2019)')
xlabel('Data Point Number Within Each Year')
ylabel('Deaths per Week')
title('Data (ITALY) Separated by Year')

subplot(2,3,3)
hold all;
plot(ExcessDeaths_IT.DeathsExcess(257:273),'o-')
title('Excess Deaths (ITALY) in 2020 Above 2015-2019 Median')
grid on;box on;
xlabel('Data Point Number Within 2020')
ylabel('Deaths per Week')


subplot(2,3,4)
hold all;
plot(data_IT.date,data_IT.DeathsPD)
grid on;box on;
title('Deaths Per Day (ITALY) From Open Covid Dataset')
ylabel('Deaths per Day')

subplot(2,3,5)
hold all;
plot(data_IT.date,data_IT.DeathsPD)
plot(ExcessDeaths_IT.date(257:273),ExcessDeaths_IT.DeathsExcess(257:273)/7,'o-')
plot(data_IT.date,data_IT.DeathsPD*1.9)
grid on;box on;
legend('Deaths per Day (Open Covid)','Weekly Excess Deaths / 7','Deaths per Day x 1.9')
title('Deaths Per Day vs Excess Deaths (ITALY)')
ylim([-200 3000])
ylabel('Deaths per Day')
%% LOMBARDY
figure;
subplot(2,3,1)
hold all;
plot(ExcessDeaths_25.date(1:14),ExcessDeaths_25.DeathsRecorded(1:14))
plot(ExcessDeaths_25.date(15:28),ExcessDeaths_25.DeathsRecorded(15:28))
plot(ExcessDeaths_25.date(29:42),ExcessDeaths_25.DeathsRecorded(29:42))
plot(ExcessDeaths_25.date(43:56),ExcessDeaths_25.DeathsRecorded(43:56))
plot(ExcessDeaths_25.date(57:70),ExcessDeaths_25.DeathsRecorded(57:70))
plot(ExcessDeaths_25.date(71:82),ExcessDeaths_25.DeathsRecorded(71:82))
grid on;box on;
xlabel('Date')
ylabel('Deaths per Week')
title('Raw Data (LOMBARDY) from Financial Times Github')

subplot(2,3,2)
hold all;
plot(ExcessDeaths_25.DeathsRecorded(1:14))
plot(ExcessDeaths_25.DeathsRecorded(15:28))
plot(ExcessDeaths_25.DeathsRecorded(29:42))
plot(ExcessDeaths_25.DeathsRecorded(43:56))
plot(ExcessDeaths_25.DeathsRecorded(57:70))
plot(ExcessDeaths_25.DeathsRecorded(71:82))
plot(ExcessDeaths_25.DeathsExpected(1:14),'LineWidth',2)
grid on;box on;
legend('2015','2016','2017','2018','2019','2020','Expected (Median 2015-2019)')
xlabel('Data Point Number Within Each Year')
ylabel('Deaths per Week')
title('Data (LOMBARDY) Separated by Year')

subplot(2,3,3)
hold all;
plot(ExcessDeaths_25.DeathsExcess(71:82),'o-')
title('Excess Deaths (LOMBARDY) in 2020 Above 2015-2019 Median')
grid on;box on;
xlabel('Data Point Number Within 2020')
ylabel('Deaths per Week')


subplot(2,3,4)
hold all;
plot(data_IT_25.date,data_IT_25.DeathsPD)
grid on;box on;
title('Deaths Per Day (LOMBARDY) From Open Covid Dataset')
ylabel('Deaths per Day')

subplot(2,3,5)
hold all;
plot(data_IT_25.date,data_IT_25.DeathsPD)
plot(ExcessDeaths_25.date(71:82),ExcessDeaths_25.DeathsExcess(71:82)/7,'o-')
plot(data_IT_25.date,data_IT_25.DeathsPD*1.9)
grid on;box on;
legend('Deaths per Day (Open Covid)','Weekly Excess Deaths / 7','Deaths per Day x 1.9')
title('Deaths Per Day vs Excess Deaths (LOMBARDY)')
ylim([-100 1500])
ylabel('Deaths per Day')
%% SPAIN
figure;
subplot(2,3,1)
hold all;
plot(ExcessDeaths_ES.date(1:33),ExcessDeaths_ES.DeathsRecorded(1:33))
plot(ExcessDeaths_ES.date(34:83),ExcessDeaths_ES.DeathsRecorded(34:83))
plot(ExcessDeaths_ES.date(84:102),ExcessDeaths_ES.DeathsRecorded(84:102))
grid on;box on;
xlabel('Date')
ylabel('Deaths per Week')
title('Raw Data (SPAIN) from Financial Times Github')

subplot(2,3,2)
hold all;
plot(ExcessDeaths_ES.DeathsRecorded(1:33))
plot(ExcessDeaths_ES.DeathsRecorded(34:83))
plot(ExcessDeaths_ES.DeathsRecorded(84:102))
plot(ExcessDeaths_ES.DeathsExpected(1:33),'LineWidth',2)
plot(ExcessDeaths_ES.DeathsExpected(34:83),'LineWidth',2)
plot(ExcessDeaths_ES.DeathsExpected(84:102),'LineWidth',2)
grid on;box on;
legend('2018','2019','2020','Expected 2018','Expected 2019','Expected 2020')
xlabel('Data Point Number Within Each Year')
ylabel('Deaths per Week')
title('Data (SPAIN) Separated by Year')

subplot(2,3,3)
hold all;
plot(ExcessDeaths_ES.DeathsExcess(84:102),'o-')
title('Excess Deaths (SPAIN) in 2020 Above 2015-2019 Median')
grid on;box on;
xlabel('Data Point Number Within 2020')
ylabel('Deaths per Week')


subplot(2,3,4)
hold all;
plot(data_ES.date,data_ES.DeathsPD)
grid on;box on;
title('Deaths Per Day (SPAIN) From Open Covid Dataset')
ylabel('Deaths per Day')

subplot(2,3,5)
hold all;
plot(data_ES.date,data_ES.DeathsPD)
plot(ExcessDeaths_ES.date(84:102),ExcessDeaths_ES.DeathsExcess(84:102)/7,'o-')
plot(data_ES.date,data_ES.DeathsPD*1.4)
grid on;box on;
legend('Deaths per Day (Open Covid)','Weekly Excess Deaths / 7','Deaths per Day x 1.4')
title('Deaths Per Day vs Excess Deaths (SPAIN)')
ylim([-100 2000])
ylabel('Deaths per Day')
%% MADRID
figure;
subplot(2,3,1)
hold all;
plot(ExcessDeaths_MD.date(1:33),ExcessDeaths_MD.DeathsRecorded(1:33))
plot(ExcessDeaths_MD.date(34:83),ExcessDeaths_MD.DeathsRecorded(34:83))
plot(ExcessDeaths_MD.date(84:102),ExcessDeaths_MD.DeathsRecorded(84:102))
grid on;box on;
xlabel('Date')
ylabel('Deaths per Week')
title('Raw Data (MADRID) from Financial Times Github')

subplot(2,3,2)
hold all;
plot(ExcessDeaths_MD.DeathsRecorded(1:33))
plot(ExcessDeaths_MD.DeathsRecorded(34:83))
plot(ExcessDeaths_MD.DeathsRecorded(84:102))
plot(ExcessDeaths_MD.DeathsExpected(1:33),'LineWidth',2)
plot(ExcessDeaths_MD.DeathsExpected(34:83),'LineWidth',2)
plot(ExcessDeaths_MD.DeathsExpected(84:102),'LineWidth',2)
grid on;box on;
legend('2018','2019','2020','Expected 2018','Expected 2019','Expected 2020')
xlabel('Data Point Number Within Each Year')
ylabel('Deaths per Week')
title('Data (MADRID) Separated by Year')

subplot(2,3,3)
hold all;
plot(ExcessDeaths_MD.DeathsExcess(84:102),'o-')
title('Excess Deaths (MADRID) in 2020 Above 2015-2019 Median')
grid on;box on;
xlabel('Data Point Number Within 2020')
ylabel('Deaths per Week')


subplot(2,3,4)
hold all;
plot(data_ES_MD.date,data_ES_MD.DeathsPD)
grid on;box on;
title('Deaths Per Day (MADRID) From Open Covid Dataset')
ylabel('Deaths per Day')

subplot(2,3,5)
hold all;
plot(data_ES_MD.date,data_ES_MD.DeathsPD)
plot(ExcessDeaths_ES.date(84:102),ExcessDeaths_ES.DeathsExcess(84:102)/7,'o-')
plot(data_ES_MD.date,data_ES_MD.DeathsPD*4)
grid on;box on;
legend('Deaths per Day (Open Covid)','Weekly Excess Deaths / 7','Deaths per Day x 4')
title('Deaths Per Day vs Excess Deaths (MADRID)')
ylim([-100 2000])
ylabel('Deaths per Day')

%% US
figure;
subplot(2,3,1)
hold all;
plot(ExcessDeaths_US.date(102:152),ExcessDeaths_US.DeathsRecorded(102:152))
plot(ExcessDeaths_US.date(153:203),ExcessDeaths_US.DeathsRecorded(153:203))
plot(ExcessDeaths_US.date(204:254),ExcessDeaths_US.DeathsRecorded(204:254))
plot(ExcessDeaths_US.date(255:305),ExcessDeaths_US.DeathsRecorded(255:305))
plot(ExcessDeaths_US.date(306:356),ExcessDeaths_US.DeathsRecorded(306:356))
plot(ExcessDeaths_US.date(357:373),ExcessDeaths_US.DeathsRecorded(357:373))
grid on;box on;
xlabel('Date')
ylabel('Deaths per Week')
title('Raw Data (US) from Financial Times Github')

subplot(2,3,2)
hold all;
plot(ExcessDeaths_US.DeathsRecorded(102:152))
plot(ExcessDeaths_US.DeathsRecorded(153:203))
plot(ExcessDeaths_US.DeathsRecorded(204:254))
plot(ExcessDeaths_US.DeathsRecorded(255:305))
plot(ExcessDeaths_US.DeathsRecorded(306:356))
plot(ExcessDeaths_US.DeathsRecorded(357:373))
plot(ExcessDeaths_US.DeathsExpected(306:356),'LineWidth',2)
grid on;box on;
legend('2015','2016','2017','2018','2019','2020','Expected (Median 2015-2019)')
xlabel('Data Point Number Within Each Year')
ylabel('Deaths per Week')
title('Data (US) Separated by Year')

subplot(2,3,3)
hold all;
plot(ExcessDeaths_US.DeathsExcess(357:373),'o-')
title('Excess Deaths (US) in 2020 Above 2015-2019 Median')
grid on;box on;
xlabel('Data Point Number Within 2020')
ylabel('Deaths per Week')


subplot(2,3,4)
hold all;
plot(data_US.date,data_US.DeathsPD)
grid on;box on;
title('Deaths Per Day (US) From Open Covid Dataset')
ylabel('Deaths per Day')

subplot(2,3,5)
hold all;
plot(data_US.date,data_US.DeathsPD)
plot(ExcessDeaths_US.date(357:373),ExcessDeaths_US.DeathsExcess(357:373)/7,'o-')
plot(data_US.date,data_US.DeathsPD*1.3)
grid on;box on;
legend('Deaths per Day (Open Covid)','Weekly Excess Deaths / 7','Deaths per Day x 1','location','NorthWest')
title('Deaths Per Day vs Excess Deaths (US)')
ylim([-200 5000])
ylabel('Deaths per Day')

%% NYC
figure;
subplot(2,3,1)
hold all;
plot(ExcessDeaths_NYC.date(102:152),ExcessDeaths_NYC.DeathsRecorded(102:152))
plot(ExcessDeaths_NYC.date(153:203),ExcessDeaths_NYC.DeathsRecorded(153:203))
plot(ExcessDeaths_NYC.date(204:254),ExcessDeaths_NYC.DeathsRecorded(204:254))
plot(ExcessDeaths_NYC.date(255:305),ExcessDeaths_NYC.DeathsRecorded(255:305))
plot(ExcessDeaths_NYC.date(306:356),ExcessDeaths_NYC.DeathsRecorded(306:356))
plot(ExcessDeaths_NYC.date(357:374),ExcessDeaths_NYC.DeathsRecorded(357:374))
grid on;box on;
xlabel('Date')
ylabel('Deaths per Week')
title('Raw Data (NYC) from Financial Times Github')

subplot(2,3,2)
hold all;
plot(ExcessDeaths_NYC.DeathsRecorded(102:152))
plot(ExcessDeaths_NYC.DeathsRecorded(153:203))
plot(ExcessDeaths_NYC.DeathsRecorded(204:254))
plot(ExcessDeaths_NYC.DeathsRecorded(255:305))
plot(ExcessDeaths_NYC.DeathsRecorded(306:356))
plot(ExcessDeaths_NYC.DeathsRecorded(357:374))
plot(ExcessDeaths_NYC.DeathsExpected(306:356),'LineWidth',2)
grid on;box on;
legend('2015','2016','2017','2018','2019','2020','Expected (Median 2015-2019)')
xlabel('Data Point Number Within Each Year')
ylabel('Deaths per Week')
title('Data (NYC) Separated by Year')

subplot(2,3,3)
hold all;
plot(ExcessDeaths_NYC.DeathsExcess(357:374),'o-')
title('Excess Deaths (NYC) in 2020 Above 2015-2019 Median')
grid on;box on;
xlabel('Data Point Number Within 2020')
ylabel('Deaths per Week')


subplot(2,3,4)
hold all;
plot(data_US_NYC.date,data_US_NYC.DeathsPD_US_NYC)
grid on;box on;
title('Deaths Per Day (NYC) From Open Covid Dataset')
ylabel('Deaths per Day')

subplot(2,3,5)
hold all;
plot(data_US_NYC.date,data_US_NYC.DeathsPD_US_NYC)
plot(ExcessDeaths_NYC.date(357:374),ExcessDeaths_NYC.DeathsExcess(357:374)/7,'o-')
plot(data_US_NYC.date,data_US_NYC.DeathsPD_US_NYC*1.7)
grid on;box on;
legend('Deaths per Day (Open Covid)','Weekly Excess Deaths / 7','Deaths per Day x 1.7','location','NorthWest')
title('Deaths Per Day vs Excess Deaths (NYC)')
ylim([-100 1500])
ylabel('Deaths per Day')

%% ENGLAND
figure;
subplot(2,3,1)
hold all;
plot(ExcessDeaths_EN.date(256:306),ExcessDeaths_EN.DeathsRecorded(256:306))
plot(ExcessDeaths_EN.date(307:357),ExcessDeaths_EN.DeathsRecorded(307:357))
plot(ExcessDeaths_EN.date(358:408),ExcessDeaths_EN.DeathsRecorded(358:408))
plot(ExcessDeaths_EN.date(409:459),ExcessDeaths_EN.DeathsRecorded(409:459))
plot(ExcessDeaths_EN.date(460:510),ExcessDeaths_EN.DeathsRecorded(460:510))
plot(ExcessDeaths_EN.date(511:530),ExcessDeaths_EN.DeathsRecorded(511:530))
grid on;box on;
xlabel('Date')
ylabel('Deaths per Week')
title('Raw Data (ENGLAND) from Financial Times Github')

subplot(2,3,2)
hold all;
plot(ExcessDeaths_EN.DeathsRecorded(256:306))
plot(ExcessDeaths_EN.DeathsRecorded(307:357))
plot(ExcessDeaths_EN.DeathsRecorded(358:408))
plot(ExcessDeaths_EN.DeathsRecorded(409:459))
plot(ExcessDeaths_EN.DeathsRecorded(460:510))
plot(ExcessDeaths_EN.DeathsRecorded(511:530))
plot(ExcessDeaths_EN.DeathsExpected(460:510),'LineWidth',2)
grid on;box on;
legend('2015','2016','2017','2018','2019','2020','Expected (Median 2015-2019)')
xlabel('Data Point Number Within Each Year')
ylabel('Deaths per Week')
title('Data (ENGLAND) Separated by Year')

subplot(2,3,3)
hold all;
plot(ExcessDeaths_EN.DeathsExcess(511:530),'o-')
title('Excess Deaths (ENGLAND) in 2020 Above 2015-2019 Median')
grid on;box on;
xlabel('Data Point Number Within 2020')
ylabel('Deaths per Week')


subplot(2,3,4)
hold all;
plot(data_EN_ExcLDN.date,data_EN_ExcLDN.DeathsPD_EN)
grid on;box on;
title('Deaths Per Day (ENGLAND) From Open Covid Dataset')
ylabel('Deaths per Day')

subplot(2,3,5)
hold all;
plot(data_EN_ExcLDN.date,data_EN_ExcLDN.DeathsPD_EN)
plot(ExcessDeaths_EN.date(511:530),ExcessDeaths_EN.DeathsExcess(511:530)/7,'o-')
plot(data_EN_ExcLDN.date,data_EN_ExcLDN.DeathsPD_EN*2)
grid on;box on;
legend('Deaths per Day (Open Covid)','Weekly Excess Deaths / 7','Deaths per Day x 2','location','NorthWest')
title('Deaths Per Day vs Excess Deaths (ENGLAND)')
ylim([-100 2200])
ylabel('Deaths per Day')

%% LONDON
figure;
subplot(2,3,1)
hold all;
plot(ExcessDeaths_LDN.date(256:306),ExcessDeaths_LDN.DeathsRecorded(256:306))
plot(ExcessDeaths_LDN.date(307:357),ExcessDeaths_LDN.DeathsRecorded(307:357))
plot(ExcessDeaths_LDN.date(358:408),ExcessDeaths_LDN.DeathsRecorded(358:408))
plot(ExcessDeaths_LDN.date(409:459),ExcessDeaths_LDN.DeathsRecorded(409:459))
plot(ExcessDeaths_LDN.date(460:510),ExcessDeaths_LDN.DeathsRecorded(460:510))
plot(ExcessDeaths_LDN.date(511:530),ExcessDeaths_LDN.DeathsRecorded(511:530))
grid on;box on;
xlabel('Date')
ylabel('Deaths per Week')
title('Raw Data (LONDON) from Financial Times Github')

subplot(2,3,2)
hold all;
plot(ExcessDeaths_LDN.DeathsRecorded(256:306))
plot(ExcessDeaths_LDN.DeathsRecorded(307:357))
plot(ExcessDeaths_LDN.DeathsRecorded(358:408))
plot(ExcessDeaths_LDN.DeathsRecorded(409:459))
plot(ExcessDeaths_LDN.DeathsRecorded(460:510))
plot(ExcessDeaths_LDN.DeathsRecorded(511:530))
plot(ExcessDeaths_LDN.DeathsExpected(460:510),'LineWidth',2)
grid on;box on;
legend('2015','2016','2017','2018','2019','2020','Expected (Median 2015-2019)')
xlabel('Data Point Number Within Each Year')
ylabel('Deaths per Week')
title('Data (LONDON) Separated by Year')

subplot(2,3,3)
hold all;
plot(ExcessDeaths_LDN.DeathsExcess(511:530),'o-')
title('Excess Deaths (LONDON) in 2020 Above 2015-2019 Median')
grid on;box on;
xlabel('Data Point Number Within 2020')
ylabel('Deaths per Week')


subplot(2,3,4)
hold all;
plot(data_EN_ExcLDN.date,data_EN_ExcLDN.DeathsPD_EN_LDN)
grid on;box on;
title('Deaths Per Day (LONDON) From Open Covid Dataset')
ylabel('Deaths per Day')

subplot(2,3,5)
hold all;
plot(data_EN_ExcLDN.date,data_EN_ExcLDN.DeathsPD_EN_LDN)
plot(ExcessDeaths_LDN.date(511:530),ExcessDeaths_LDN.DeathsExcess(511:530)/7,'o-')
plot(data_EN_ExcLDN.date,data_EN_ExcLDN.DeathsPD_EN_LDN*1.5)
grid on;box on;
legend('Deaths per Day (Open Covid)','Weekly Excess Deaths / 7','Deaths per Day x 1.5','location','NorthWest')
title('Deaths Per Day vs Excess Deaths (LONDON)')
ylim([-100 700])
ylabel('Deaths per Day')


%% PLOT ALL TOGETHER
figure;
subplot(2,4,1)
hold all;
plot([1:1:length(ExcessDeaths_IT.DeathsExcess(257:273))]*7+3,ExcessDeaths_IT.DeathsExcess(257:273)/7,'o-','MarkerSize',4,'MarkerFaceColor','b')
plot(1:1:length(data_IT.DeathsPD),data_IT.DeathsPD*1.9)
grid on;box on;
legend('Weekly Excess/7','Deaths/Day x 1.9')
title('ITALY')
ylim([-200 3000])
xlim([60 150])
ylabel('Deaths per Day')


subplot(2,4,2)
hold all;
plot([1:1:length(ExcessDeaths_25.DeathsExcess(71:82))]*7-47,ExcessDeaths_25.DeathsExcess(71:82)/7,'o-','MarkerSize',4,'MarkerFaceColor','b')
plot(1:1:length(data_IT_25.DeathsPD),data_IT_25.DeathsPD*1.9)
grid on;box on;
legend('Weekly Excess/7','Deaths/Day x 1.9')
title('LOMBARDY')
ylim([-100 1500])
xlim([0 100])
ylabel('Deaths per Day')

subplot(2,4,3)
hold all;
plot([1:1:length(ExcessDeaths_ES.DeathsExcess(84:102))]*7,ExcessDeaths_ES.DeathsExcess(84:102)/7,'o-','MarkerSize',4,'MarkerFaceColor','b')
plot(1:1:length(data_ES.DeathsPD),data_ES.DeathsPD*1.4)
grid on;box on;
legend('Weekly Excess/7','Deaths/Day x 1.4')
title('SPAIN')
ylim([-100 2000])
xlim([60 150])
ylabel('Deaths per Day')

subplot(2,4,4)
hold all;
plot([1:1:length(ExcessDeaths_MD.DeathsExcess(84:102))]*7-53,ExcessDeaths_MD.DeathsExcess(84:102)/7,'o-','MarkerSize',4,'MarkerFaceColor','b')
plot(1:1:length(data_ES_MD.DeathsPD),data_ES_MD.DeathsPD*1.4)
grid on;box on;
legend('Weekly Excess/7','Deaths/Day x 1.4')
title('MADRID')
ylim([-100 2000])
xlim([10 90])
ylabel('Deaths per Day')

subplot(2,4,5)
hold all;
plot([1:1:length(ExcessDeaths_US.DeathsExcess(357:373))]*7,ExcessDeaths_US.DeathsExcess(357:373)/7,'o-','MarkerSize',4,'MarkerFaceColor','b')
plot(1:1:length(data_US.DeathsPD),data_US.DeathsPD*1.5)
grid on;box on;
legend('Weekly Excess/7','Deaths/Day x 1.5')
title('US')
ylim([-200 8000])
xlim([60 155])
ylabel('Deaths per Day')

subplot(2,4,6)
hold all;
plot([1:1:length(ExcessDeaths_NYC.DeathsExcess(357:374))]*7-50,ExcessDeaths_NYC.DeathsExcess(357:374)/7,'o-','MarkerSize',4,'MarkerFaceColor','b')
plot(1:1:length(data_US_NYC.DeathsPD_US_NYC),data_US_NYC.DeathsPD_US_NYC*1.5)
grid on;box on;
legend('Weekly Excess/7','Deaths/Day x 1.5')
title('NYC')
ylim([-100 1500])
xlim([20 110])
ylabel('Deaths per Day')

subplot(2,4,7)
hold all;
plot([1:1:length(ExcessDeaths_EN.DeathsExcess(511:530))]*7-10,ExcessDeaths_EN.DeathsExcess(511:530)/7,'o-','MarkerSize',4,'MarkerFaceColor','b')
plot(1:1:length(data_EN_ExcLDN.DeathsPD_EN),data_EN_ExcLDN.DeathsPD_EN*2.2)
grid on;box on;
legend('Weekly Excess/7','Deaths/Day x 2.2')
title('ENGLAND')
ylim([-100 2500])
xlim([60 140])
ylabel('Deaths per Day')

subplot(2,4,8)
hold all;
plot([1:1:length(ExcessDeaths_LDN.DeathsExcess(511:530))]*7-10,ExcessDeaths_LDN.DeathsExcess(511:530)/7,'o-','MarkerSize',4,'MarkerFaceColor','b')
plot(1:1:length(data_EN_ExcLDN.DeathsPD_EN_LDN),data_EN_ExcLDN.DeathsPD_EN_LDN*2.2)
grid on;box on;
legend('Weekly Excess/7','Deaths/Day x 2.2')
title('LONDON')
ylim([-100 700])
xlim([60 140])
ylabel('Deaths per Day')
