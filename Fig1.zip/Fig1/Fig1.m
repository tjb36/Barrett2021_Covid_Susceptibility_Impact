clear;clc;close all;

%%% IMPORT OPEN COVID DATA %%%
%%% This section produces a timetable object called "OpenCovid_data_full" with 
%%% ALL the data from the Open Covid data set (all available countries). This 
%%% table will then be filtered down to only the relevant countries later in the code.

% Set up the import options
data_filename_OpenCovid = 'master.csv'; % from: https://github.com/open-covid-19/data
opts = detectImportOptions(data_filename_OpenCovid);
opts.VariableTypes([1:11 26]) = {'string'}; % Make sure text-based columns are imported as "string"
opts.VariableTypes([12:16 18:25 27:63]) = {'double'}; % Make sure numeric-based columns are imported as "double"

OpenCovid_data_full = readtable(data_filename_OpenCovid,opts); % Import the .csv file as a table object

% Clean up result, and calculate some extra useful quantites
OpenCovid_data_full = OpenCovid_data_full(:,[1 5:9 17 19 32:40 58 59]); % Discard the irrelevant columns
OpenCovid_data_full.date.Format = 'dd-MMM-yyyy'; % Correct the datetime format
OpenCovid_data_full = table2timetable(OpenCovid_data_full); % Convert to timetable object (easier for dealing with dates)
OpenCovid_data_full.Properties.VariableNames{strcmp(OpenCovid_data_full.Properties.VariableNames,'new_deceased')} = 'DeathsPD'; % rename column
OpenCovid_data_full.DeathsPD(OpenCovid_data_full.DeathsPD<=0) = NaN; % Set to NaN to prevent problems on log scale
OpenCovid_data_full.days = datenum(OpenCovid_data_full.date) - datenum('01-Jan-2020'); % Create a "days since Jan 1st" column (helpful for fitting)
OpenCovid_data_full.DeathsPDPM = OpenCovid_data_full.DeathsPD./OpenCovid_data_full.population*1e6; % Deaths per day per million
OpenCovid_data_full.LOG_DeathsPDPM = log(OpenCovid_data_full.DeathsPDPM); % Log( Deaths/day/million )
clear opts data_filename_OpenCovid
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% DATA FOR FOUR COUNTRIES
data_ES = OpenCovid_data_full(OpenCovid_data_full.('key')=='ES',:);
data_IT = OpenCovid_data_full(OpenCovid_data_full.('key')=='IT',:);
data_GB = OpenCovid_data_full(OpenCovid_data_full.('key')=='GB',:);
data_US = OpenCovid_data_full(OpenCovid_data_full.('key')=='US',:);

% Fit initial slopes
[fitresult_ES, gof_ES] = fit_initial_slope(data_ES.days, data_ES.LOG_DeathsPDPM, [13:150]);
coeffvalues_ES = coeffvalues(fitresult_ES);
[fitresult_IT, gof_IT] = fit_initial_slope(data_IT.days, data_IT.LOG_DeathsPDPM, [2:3 15:150]);
coeffvalues_IT = coeffvalues(fitresult_IT);
[fitresult_GB, gof_GB] = fit_initial_slope(data_GB.days, data_GB.LOG_DeathsPDPM, [15:150]);
coeffvalues_GB = coeffvalues(fitresult_GB);
[fitresult_US, gof_US] = fit_initial_slope(data_US.days, data_US.LOG_DeathsPDPM, [1:5 25:150]);
coeffvalues_US = coeffvalues(fitresult_US);

slopes = [coeffvalues_ES(1) coeffvalues_IT(1) coeffvalues_GB(1) coeffvalues_US(1)];

% Fitted curves
t_fit = linspace(0,200,1000);
y_fit_ES = exp(coeffvalues_ES(1)*t_fit)*exp(coeffvalues_ES(2));
y_fit_IT = exp(coeffvalues_IT(1)*t_fit)*exp(coeffvalues_IT(2));
y_fit_GB = exp(coeffvalues_GB(1)*t_fit)*exp(coeffvalues_GB(2));
y_fit_US = exp(coeffvalues_US(1)*t_fit)*exp(coeffvalues_US(2));

y_mean = exp(mean(slopes)*t_fit)*exp(coeffvalues_ES(2));
y_max = exp(max(slopes)*t_fit)*exp(coeffvalues_ES(2));
y_min = exp(min(slopes)*t_fit)*exp(coeffvalues_ES(2));

% Align data to 0.01 deaths per day per million
startValue = 0.01;
t_RelOff_ES = t_fit(min(find(y_fit_ES > startValue)));
t_RelOff_IT = t_fit(min(find(y_fit_IT > startValue)));
t_RelOff_GB = t_fit(min(find(y_fit_GB > startValue)));
t_RelOff_US = t_fit(min(find(y_fit_US > startValue)));

t_RelOff_mean = t_fit(min(find(y_mean > startValue)));
t_RelOff_max = t_fit(min(find(y_max > startValue)));
t_RelOff_min = t_fit(min(find(y_min > startValue)));

x2 = [t_fit-t_RelOff_max, fliplr(t_fit-t_RelOff_min)];
inBetween = [y_max, fliplr(y_min)];


%% Plotting
data_ES.DeathsPDPM(144) = NaN;     % Unphysical large value when Spain reporting was adjusted on 22 May
data_US.DeathsPDPM([62:65]) = NaN; % Discard first few values with 1 death per day

f1 = figure('Position',[442 198 579  553],'color','w');hold all;
p1 = plot(data_ES.days(~isnan(data_ES.DeathsPDPM)) - t_RelOff_ES+1, smooth(data_ES.DeathsPDPM(~isnan(data_ES.DeathsPDPM)),7),'o');
p3 = plot(data_IT.days(~isnan(data_IT.DeathsPDPM)) - t_RelOff_IT, smooth(data_IT.DeathsPDPM(~isnan(data_IT.DeathsPDPM)),7),'s');
p4 = plot(data_GB.days(~isnan(data_GB.DeathsPDPM)) - t_RelOff_GB, smooth(data_GB.DeathsPDPM(~isnan(data_GB.DeathsPDPM)),7),'^');
p5 = plot(data_US.days(~isnan(data_US.DeathsPDPM)) - t_RelOff_US, smooth(data_US.DeathsPDPM(~isnan(data_US.DeathsPDPM)),7),'d');
p_fit = plot(t_fit - t_RelOff_mean, y_mean,'k');
fill1 = fill(x2, inBetween, 'g');

ax2 = gca;
set(ax2,'Position',[0.1714    0.5803    0.7070    0.3447])
ylabel(ax2,{'Deaths per day';'per million population'})
xlabel(ax2,'Days relative to 0.01 deaths per day per million')
set(ax2,'XLim',[-2 70],'YLim',[5e-3 1e2],'YScale','log')
legend([p1;p3;p4;p5],'Spain','Italy','UK','US','location','SouthEast')
set(fill1,'FaceAlpha',0.4,'FaceColor',[158,154,200]/255,'LineStyle','none');

load('SocialDATA_LDN_UK.mat')

ax1 = axes;hold all;
set(ax1,'Position',[0.1688    0.1172    0.7124    0.3413])
p(1) = plot(StringencyIndex_UK.date, StringencyIndex_UK.SI);
p(2) = plot(OpenTable_UK.date, OpenTable_UK.OT);
p(3) = plot(OpenTable_London.date, OpenTable_London.OT);
p(4) = plot(Google_UK.date, Google_UK.TS);
p(5) = plot(Google_UK.date, Google_UK.GP);
p(6) = plot(Google_GreaterLondon.date, Google_GreaterLondon.TS);
p(7) = plot(Google_GreaterLondon.date, Google_GreaterLondon.GP);
p(8) = plot(GoogleSearches_UK.date, GoogleSearches_UK.Searches);
p(9) = line([datetime('23-Mar-2020') datetime('23-Mar-2020')],[-125 125]);

red = [203,24,29]/255;
blue = [33,113,181]/255;
green = [27,120,55]/255;
darkred = [165,15,21]/255;

ylabel(ax1,{'Change in Index';'For UK and London [%]'})
set(ax1,'XLim',[datetime('21-Feb-2020') datetime('04-May-2020')],'YLim',[-125 125],'XTick',datetime({'01-Feb-2020'   '01-Mar-2020'   '01-Apr-2020'   '01-May-2020'}))

%%% Line Colours
set(p((1)),'color',red)
set(p((8)),'color',red)
set(p([2 4 5]),'color',red)
set(p([3 6 7]),'color',blue)
set(p(9),'color','k')
set(p([4 6]),'LineStyle','-.')
set(p([5 7]),'LineStyle','--')
set(p([2 3]),'LineStyle',':') 
set(p(9),'LineStyle','--')


