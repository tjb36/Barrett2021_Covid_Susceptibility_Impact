function [fitresult, gof, t_fit, y_fit] = fit_linear_slope(x, y, exc_indices)

[xData, yData] = prepareCurveData( x, y );

exc_indices(exc_indices > length(xData)) = [];
% Set up fittype and options.
ft = fittype( 'a*x + b', 'independent', 'x', 'dependent', 'y' );
excludedPoints = excludedata( xData, yData, 'Indices', exc_indices);
opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
opts.Display = 'Off';
opts.StartPoint = [0.3 -10];
opts.Exclude = excludedPoints;

% Fit model to data.
[fitresult, gof] = fit( xData, yData, ft, opts );

t_fit = linspace(0,200,1000);
coeff_values = coeffvalues(fitresult);
% 
y_fit = coeff_values(1)*t_fit + coeff_values(2);


% Plot fit with data.
h = plot( fitresult, xData, yData, excludedPoints,'r+' );
legend( h, 'Data', 'Excluded Points', ['Slope = ',num2str(coeff_values(1))], 'Location', 'SouthEast' );
% Label axes
xlabel x
ylabel y
grid on
ylim([-5 5])


end

