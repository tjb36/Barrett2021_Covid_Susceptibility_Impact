clear;clc;close all;

%%% IMPORT OPEN COVID DATA %%%
%%% This section produces a timetable object called "OpenCovid_data_full" with 
%%% ALL the data from the Open Covid data set (all available countries). This 
%%% table will then be filtered down to only the relevant countries later in the code.

% Set up the import options
data_filename_OpenCovid = 'master.csv'; % from: https://github.com/open-covid-19/data
opts = detectImportOptions(data_filename_OpenCovid);
opts.VariableTypes([1:11 26]) = {'string'}; % Make sure text-based columns are imported as "string"
opts.VariableTypes([12:16 18:25 27:63]) = {'double'}; % Make sure numeric-based columns are imported as "double"

OpenCovid_data_full = readtable(data_filename_OpenCovid,opts); % Import the .csv file as a table object

% Clean up result, and calculate some extra useful quantites
OpenCovid_data_full = OpenCovid_data_full(:,[1 5:9 17 19 32:40 58 59]); % Discard the irrelevant columns
OpenCovid_data_full.date.Format = 'dd-MMM-yyyy'; % Correct the datetime format
OpenCovid_data_full = table2timetable(OpenCovid_data_full); % Convert to timetable object (easier for dealing with dates)
OpenCovid_data_full.Properties.VariableNames{strcmp(OpenCovid_data_full.Properties.VariableNames,'new_deceased')} = 'DeathsPD'; % rename column
OpenCovid_data_full.DeathsPD(OpenCovid_data_full.DeathsPD<=0) = NaN; % Set to NaN to prevent problems on log scale
OpenCovid_data_full.days = datenum(OpenCovid_data_full.date) - datenum('01-Jan-2020'); % Create a "days since Jan 1st" column (helpful for fitting)
OpenCovid_data_full.DeathsPDPM = OpenCovid_data_full.DeathsPD./OpenCovid_data_full.population*1e6; % Deaths per day per million
OpenCovid_data_full.LOG_DeathsPDPM = log(OpenCovid_data_full.DeathsPDPM); % Log( Deaths/day/million )
clear opts data_filename_OpenCovid
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% SPAIN %%

% Get Madrid and Spain data
data_ES = OpenCovid_data_full(OpenCovid_data_full.('key')=='ES',:);
data_ES_MD = OpenCovid_data_full(OpenCovid_data_full.('key')=='ES_MD',:);
 
% Combine Spain data and Madrid data into a single synochornized timetable
temp1 = timetable(data_ES.date, data_ES.DeathsPD, data_ES.population,'VariableNames',{'DeathsPD_ES','population_ES'});
temp2 = timetable(data_ES_MD.date, data_ES_MD.DeathsPD, data_ES_MD.population,'VariableNames',{'DeathsPD_ES_MD','population_ES_MD'});
data_ES_ExcMD = synchronize(temp1, temp2);
clear temp1 temp2
data_ES_ExcMD.Properties.DimensionNames{1} = 'date';
data_ES_ExcMD.days = datenum(data_ES_ExcMD.date) - datenum('01-Jan-2020');

% Subtract Madrid from Spain
data_ES_ExcMD.population_ES_MD(:) = mean(data_ES_ExcMD.population_ES_MD(~isnan(data_ES_ExcMD.population_ES_MD))); % Make sure none of the population values are NaN
data_ES_ExcMD.population = data_ES_ExcMD.population_ES - data_ES_ExcMD.population_ES_MD;
data_ES_ExcMD.DeathsPD = data_ES_ExcMD.DeathsPD_ES - data_ES_ExcMD.DeathsPD_ES_MD; 

% Put some values to 1000 so we can see bad ones on the graph
data_ES_ExcMD.DeathsPD(data_ES_ExcMD.DeathsPD <= 0) = 1000; % Sometimes city is larger than country, for some reason (cannot be possible)
data_ES_ExcMD.DeathsPD_ES(data_ES_ExcMD.DeathsPD_ES <= 0) = 1000;
data_ES_ExcMD.DeathsPD_ES_MD(data_ES_ExcMD.DeathsPD_ES_MD <= 0) = 1000;

f1 = figure;
subplot(2,3,1);hold all;
plot(data_ES_ExcMD.date, data_ES_ExcMD.DeathsPD_ES,'x-')
plot(data_ES_ExcMD.date, data_ES_ExcMD.DeathsPD_ES_MD,'.-')
plot(data_ES_ExcMD.date, data_ES_ExcMD.DeathsPD,'o')
ylabel('Deaths per day');grid on;box on;
legend('Spain total','Madrid only','Spain exc. Madrid','location','NorthEast')
title({'Deaths per day for Spain (Linear scale version)';'Negative values replaced by value of 1000'})

% Put values of 1000 equal to NaN to not mess up cumulative sum
data_ES_ExcMD.DeathsPD(data_ES_ExcMD.DeathsPD == 1000) = NaN;
data_ES_ExcMD.DeathsPD_ES(data_ES_ExcMD.DeathsPD_ES==1000) = NaN;
data_ES_ExcMD.DeathsPD_ES_MD(data_ES_ExcMD.DeathsPD_ES_MD==1000) = NaN;

subplot(2,3,2);hold all;
plot(data_ES_ExcMD.date, cumsum(data_ES_ExcMD.DeathsPD_ES,'omitnan'),'x-')
plot(data_ES_ExcMD.date, cumsum(data_ES_ExcMD.DeathsPD_ES_MD,'omitnan'),'.-')
plot(data_ES_ExcMD.date, cumsum(data_ES_ExcMD.DeathsPD,'omitnan'),'+-')
ylabel('Cumulative deaths');grid on;box on;
legend('Spain total','Madrid only','Spain exc. Madrid','location','NorthWest')
title('Cumulative deaths for Spain')

subplot(2,3,3);hold all;
plot(data_ES_ExcMD.date, data_ES_ExcMD.DeathsPD_ES,'x-')
plot(data_ES_ExcMD.date, data_ES_ExcMD.DeathsPD_ES_MD,'.-')
plot(data_ES_ExcMD.date, data_ES_ExcMD.DeathsPD,'o-','MarkerFaceColor','g')
ylabel('Deaths per day');grid on;box on;
legend('Spain total','Madrid only','Spain exc. Madrid','location','SouthEast')
title({'Deaths per day for Spain (Log scale version)';'Values of 1000 been replaced with NaN'})
set(gca,'YScale','log')

% Calculate "per million"
data_ES_ExcMD.DeathsPDPM_ES =    data_ES_ExcMD.DeathsPD_ES./data_ES_ExcMD.population_ES*1e6;
data_ES_ExcMD.DeathsPDPM_ES_MD = data_ES_ExcMD.DeathsPD_ES_MD./data_ES_ExcMD.population_ES_MD*1e6;
data_ES_ExcMD.DeathsPDPM =       data_ES_ExcMD.DeathsPD./data_ES_ExcMD.population*1e6;

% Take log()
data_ES_ExcMD.LOG_DeathsPDPM_ES = log(data_ES_ExcMD.DeathsPDPM_ES);
data_ES_ExcMD.LOG_DeathsPDPM_ES_MD = log(data_ES_ExcMD.DeathsPDPM_ES_MD);
data_ES_ExcMD.LOG_DeathsPDPM = log(data_ES_ExcMD.DeathsPDPM);


subplot(2,3,4);hold all;
plot(data_ES_ExcMD.date, data_ES_ExcMD.DeathsPDPM_ES,'x-')
plot(data_ES_ExcMD.date, data_ES_ExcMD.DeathsPDPM_ES_MD,'.-')
plot(data_ES_ExcMD.date, data_ES_ExcMD.DeathsPDPM,'o-','MarkerFaceColor','g')
plot(data_ES_ExcMD.date, smooth(data_ES_ExcMD.DeathsPDPM,5),'o-','MarkerFaceColor','k','MarkerSize',2)
ylabel('Deaths per day per million');grid on;box on;
legend('Spain total','Madrid only','Spain exc. Madrid','Spain exc. Madrid (smoothed)','location','SouthEast')
title('Deaths per day per million for Spain')
set(gca,'YScale','log')

subplot(2,3,5);hold all;
plot(data_ES_ExcMD.date, data_ES_ExcMD.LOG_DeathsPDPM_ES,'x-')
plot(data_ES_ExcMD.date, data_ES_ExcMD.LOG_DeathsPDPM_ES_MD,'.-')
plot(data_ES_ExcMD.date, data_ES_ExcMD.LOG_DeathsPDPM,'o-','MarkerFaceColor','g')
ylabel('Log( Deaths per day per million )');grid on;box on;
legend('Spain total','Madrid only','Spain exc. Madrid','location','SouthEast')
title('Log[ Deaths per day per million ] for Spain')


% SEQUENTIAL FITS FOR SPAIN
figure;
subplot(2,3,1)
[fit_res1_ES_MD, ~, t_fit1_ES_MD, y_fit1_ES_MD] = fit_linear_slope(data_ES_ExcMD.days, data_ES_ExcMD.LOG_DeathsPDPM_ES_MD, [13:150]);
subplot(2,3,2)
[fit_res2_ES_MD, ~, t_fit2_ES_MD, y_fit2_ES_MD] = fit_linear_slope(data_ES_ExcMD.days, data_ES_ExcMD.LOG_DeathsPDPM_ES_MD, [1:35 76 79 80 81]);
coeff_values1_ES_MD = coeffvalues(fit_res1_ES_MD);
aU_ES_MD = coeff_values1_ES_MD(1);
coeff_values2_ES_MD = coeffvalues(fit_res2_ES_MD);
aL_ES_MD = coeff_values2_ES_MD(1);
subplot(2,3,3)
[fit_res3_ES_MD, ~, t_fit3_ES_MD, y_fit3_ES_MD] = fit_full_log_aU_aL_CON(data_ES_ExcMD.days, data_ES_ExcMD.LOG_DeathsPDPM_ES_MD, aU_ES_MD, aL_ES_MD, [76 79 80 81]);

subplot(2,3,4)
[fit_res1_ES_ExcMD, ~, t_fit1_ES_ExcMD, y_fit1_ES_ExcMD] = fit_linear_slope(data_ES_ExcMD.days, data_ES_ExcMD.LOG_DeathsPDPM, [1:6 12:150]);
subplot(2,3,5)
[fit_res2_ES_ExcMD, ~, t_fit2_ES_ExcMD, y_fit2_ES_ExcMD] = fit_linear_slope(data_ES_ExcMD.days, data_ES_ExcMD.LOG_DeathsPDPM, [1:20 63:80]);
coeff_values1_ES_ExcMD = coeffvalues(fit_res1_ES_ExcMD);
aU_ES_ExcMD = coeff_values1_ES_ExcMD(1);
coeff_values2_ES_ExcMD = coeffvalues(fit_res2_ES_ExcMD);
aL_ES_ExcMD = coeff_values2_ES_ExcMD(1);
subplot(2,3,6)
[fit_res3_ES_ExcMD, ~, t_fit3_ES_ExcMD, y_fit3_ES_ExcMD] = fit_full_log_aU_aL_CON(data_ES_ExcMD.days, data_ES_ExcMD.LOG_DeathsPDPM, aU_ES_ExcMD, aL_ES_ExcMD, [1:6 50]);

subplot(2,3,1);title('Madrid (\alpha_U Fit)')
subplot(2,3,2);title('Madrid (\alpha_L Fit)')
subplot(2,3,3);title('Madrid (Full Log Fit)')
subplot(2,3,4);title('Spain Exc. Madrid (\alpha_L Fit)')
subplot(2,3,5);title('Spain Exc. Madrid (\alpha_U Fit)')
subplot(2,3,6);title('Spain Exc. Madrid (Full Log Fit)')

% PLOT EVERYTHING TOGETHER FOR SPAIN
figure;
hold all;
p1 = plot(data_ES_ExcMD.days, data_ES_ExcMD.DeathsPDPM,'ro','MarkerSize',3,'MarkerFaceColor','r');
p2 = plot(data_ES_ExcMD.days, data_ES_ExcMD.DeathsPDPM_ES_MD,'bo','MarkerSize',3,'MarkerFaceColor','b');

p3 = plot(t_fit1_ES_ExcMD, exp(y_fit1_ES_ExcMD),'r--');
p4 = plot(t_fit2_ES_ExcMD, exp(y_fit2_ES_ExcMD),'r-.');
plot(t_fit3_ES_ExcMD, exp(y_fit3_ES_ExcMD),'r-');

p5 = plot(t_fit1_ES_MD, exp(y_fit1_ES_MD),'b--');
p6 = plot(t_fit2_ES_MD, exp(y_fit2_ES_MD),'b-.');
plot(t_fit3_ES_MD, exp(y_fit3_ES_MD),'b-');

ylabel('Deaths per day per million');grid on;box on;
legend([p1 p2 p3 p4 p5 p6],'Spain exc. Madrid data','Madrid only data',...
                           ['\alpha_U = ',num2str(aU_ES_ExcMD)],...
                           ['\alpha_L = ',num2str(aL_ES_ExcMD)],...
                           ['\alpha_U = ',num2str(aU_ES_MD)],...
                           ['\alpha_L = ',num2str(aL_ES_MD)],...
                           'location','SouthEast')
set(gca,'YScale','log')
title('Deaths per day per million with fits for Spain')
xlim([60 150]);ylim([1e-2 1e2])


%% ITALY %%

% Get Lombardy and Italy data
data_IT = OpenCovid_data_full(OpenCovid_data_full.('key')=='IT',:);
data_IT_25 = OpenCovid_data_full(OpenCovid_data_full.('key')=='IT_25',:);
 
% Combine Italy data and Lombardy data into a single synochornized timetable
temp1 = timetable(data_IT.date, data_IT.DeathsPD, data_IT.population,'VariableNames',{'DeathsPD_IT','population_IT'});
temp2 = timetable(data_IT_25.date, data_IT_25.DeathsPD, data_IT_25.population,'VariableNames',{'DeathsPD_IT_25','population_IT_25'});
data_IT_Exc25 = synchronize(temp1, temp2);
clear temp1 temp2
data_IT_Exc25.Properties.DimensionNames{1} = 'date';
data_IT_Exc25.days = datenum(data_IT_Exc25.date) - datenum('01-Jan-2020');

% Subtract Lombardy from Italy
data_IT_Exc25.population_IT_25(:) = mean(data_IT_Exc25.population_IT_25(~isnan(data_IT_Exc25.population_IT_25))); % Make sure none of the population values are NaN
data_IT_Exc25.population = data_IT_Exc25.population_IT - data_IT_Exc25.population_IT_25;
data_IT_Exc25.DeathsPD = data_IT_Exc25.DeathsPD_IT - data_IT_Exc25.DeathsPD_IT_25; 

% Put some values to 1000 so we can see bad ones on the graph
data_IT_Exc25.DeathsPD(data_IT_Exc25.DeathsPD <= 0) = 1000; % Sometimes city is larger than country, for some reason (cannot be possible)
data_IT_Exc25.DeathsPD_IT(data_IT_Exc25.DeathsPD_IT <= 0) = 1000;
data_IT_Exc25.DeathsPD_IT_25(data_IT_Exc25.DeathsPD_IT_25 <= 0) = 1000;


f2 = figure;
subplot(2,3,1);hold all;
plot(data_IT_Exc25.date, data_IT_Exc25.DeathsPD_IT,'x-')
plot(data_IT_Exc25.date, data_IT_Exc25.DeathsPD_IT_25,'.-')
plot(data_IT_Exc25.date, data_IT_Exc25.DeathsPD,'o')
ylabel('Deaths per day');grid on;box on;
legend('Italy total','Lombardy only','Italy exc. Lombardy','location','NorthEast')
title({'Deaths per day for Italy (Linear scale version)';'Negative values replaced by value of 1000'})


% Put values of 1000 equal to NaN to not mess up cumulative sum
data_IT_Exc25.DeathsPD(data_IT_Exc25.DeathsPD == 1000) = NaN;
data_IT_Exc25.DeathsPD_IT(data_IT_Exc25.DeathsPD_IT==1000) = NaN;
data_IT_Exc25.DeathsPD_IT_25(data_IT_Exc25.DeathsPD_IT_25==1000) = NaN;

subplot(2,3,2);hold all;
plot(data_IT_Exc25.date, cumsum(data_IT_Exc25.DeathsPD_IT,'omitnan'),'x-')
plot(data_IT_Exc25.date, cumsum(data_IT_Exc25.DeathsPD_IT_25,'omitnan'),'.-')
plot(data_IT_Exc25.date, cumsum(data_IT_Exc25.DeathsPD,'omitnan'),'+-')
ylabel('Cumulative deaths');grid on;box on;
legend('Italy total','Lombardy only','Italy exc. Lombardy','location','NorthWest')
title('Cumulative deaths for Italy')

subplot(2,3,3);hold all;
plot(data_IT_Exc25.date, data_IT_Exc25.DeathsPD_IT,'x-')
plot(data_IT_Exc25.date, data_IT_Exc25.DeathsPD_IT_25,'.-')
plot(data_IT_Exc25.date, data_IT_Exc25.DeathsPD,'o-','MarkerFaceColor','g')
ylabel('Deaths per day');grid on;box on;
legend('Italy total','Lombardy only','Italy exc. Lombardy','location','SouthEast')
title({'Deaths per day for Italy (Log scale version)';'Values of 1000 been replaced with NaN'})
set(gca,'YScale','log')

% Calculate "per million"
data_IT_Exc25.DeathsPDPM_IT =    data_IT_Exc25.DeathsPD_IT./data_IT_Exc25.population_IT*1e6;
data_IT_Exc25.DeathsPDPM_IT_25 = data_IT_Exc25.DeathsPD_IT_25./data_IT_Exc25.population_IT_25*1e6;
data_IT_Exc25.DeathsPDPM =       data_IT_Exc25.DeathsPD./data_IT_Exc25.population*1e6;

% Take log()
data_IT_Exc25.LOG_DeathsPDPM_IT = log(data_IT_Exc25.DeathsPDPM_IT);
data_IT_Exc25.LOG_DeathsPDPM_IT_25 = log(data_IT_Exc25.DeathsPDPM_IT_25);
data_IT_Exc25.LOG_DeathsPDPM = log(data_IT_Exc25.DeathsPDPM);


subplot(2,3,4);hold all;
plot(data_IT_Exc25.date, data_IT_Exc25.DeathsPDPM_IT,'x-')
plot(data_IT_Exc25.date, data_IT_Exc25.DeathsPDPM_IT_25,'.-')
plot(data_IT_Exc25.date, data_IT_Exc25.DeathsPDPM,'o-','MarkerFaceColor','g')
plot(data_IT_Exc25.date, smooth(data_IT_Exc25.DeathsPDPM,5),'o-','MarkerFaceColor','k','MarkerSize',2)
ylabel('Deaths per day per million');grid on;box on;
legend('Italy total','Lombardy only','Italy exc. Lombardy','Italy exc. Lombardy (smoothed)','location','SouthEast')
title('Deaths per day per million for Italy')
set(gca,'YScale','log')

subplot(2,3,5);hold all;
plot(data_IT_Exc25.date, data_IT_Exc25.LOG_DeathsPDPM_IT,'x-')
plot(data_IT_Exc25.date, data_IT_Exc25.LOG_DeathsPDPM_IT_25,'.-')
plot(data_IT_Exc25.date, data_IT_Exc25.LOG_DeathsPDPM,'o-','MarkerFaceColor','g')
ylabel('Log( Deaths per day per million )');grid on;box on;
legend('Italy total','Lombardy only','Italy exc. Lombardy','location','SouthEast')
title('Log[ Deaths per day per million ] for Italy')

% SEQUENTIAL FITS FOR ITALY
figure;
subplot(2,3,1)
[fit_res1_IT_25, ~, t_fit1_IT_25, y_fit1_IT_25] = fit_linear_slope(data_IT_Exc25.days, data_IT_Exc25.LOG_DeathsPDPM_IT_25, [13:150]);
subplot(2,3,2)
[fit_res2_IT_25, ~, t_fit2_IT_25, y_fit2_IT_25] = fit_linear_slope(data_IT_Exc25.days, data_IT_Exc25.LOG_DeathsPDPM_IT_25, [1:35 76 79 80 81]);
coeff_values1_IT_25 = coeffvalues(fit_res1_IT_25);
aU_IT_25 = coeff_values1_IT_25(1);
coeff_values2_IT_25 = coeffvalues(fit_res2_IT_25);
aL_IT_25 = coeff_values2_IT_25(1);
subplot(2,3,3)
[fit_res3_IT_25, ~, t_fit3_IT_25, y_fit3_IT_25] = fit_full_log_aU_aL_CON(data_IT_Exc25.days, data_IT_Exc25.LOG_DeathsPDPM_IT_25, aU_IT_25, aL_IT_25, [76 79 80 81]);

subplot(2,3,4)
[fit_res1_IT_Exc25, ~, t_fit1_IT_Exc25, y_fit1_IT_Exc25] = fit_linear_slope(data_IT_Exc25.days, data_IT_Exc25.LOG_DeathsPDPM, [1 16:150]);
subplot(2,3,5)
[fit_res2_IT_Exc25, ~, t_fit2_IT_Exc25, y_fit2_IT_Exc25] = fit_linear_slope(data_IT_Exc25.days, data_IT_Exc25.LOG_DeathsPDPM, [1:30 83:100]);
coeff_values1_IT_Exc25 = coeffvalues(fit_res1_IT_Exc25);
aU_IT_Exc25 = coeff_values1_IT_Exc25(1);
coeff_values2_IT_Exc25 = coeffvalues(fit_res2_IT_Exc25);
aL_IT_Exc25 = coeff_values2_IT_Exc25(1);
subplot(2,3,6)
[fit_res3_IT_Exc25, ~, t_fit3_IT_Exc25, y_fit3_IT_Exc25] = fit_full_log_aU_aL_CON(data_IT_Exc25.days, data_IT_Exc25.LOG_DeathsPDPM, aU_IT_Exc25, aL_IT_Exc25, [1 50]);

subplot(2,3,1);title('Lombardy (\alpha_U Fit)')
subplot(2,3,2);title('Lombardy (\alpha_L Fit)')
subplot(2,3,3);title('Lombardy (Full Log Fit)')
subplot(2,3,4);title('Italy Exc. Lombardy (\alpha_L Fit)')
subplot(2,3,5);title('Italy Exc. Lombardy (\alpha_U Fit)')
subplot(2,3,6);title('Italy Exc. Lombardy (Full Log Fit)')

% PLOT EVERYTHING TOGETHER FOR ITALY
figure;
hold all;
p1 = plot(data_IT_Exc25.days, data_IT_Exc25.DeathsPDPM,'ro','MarkerSize',3,'MarkerFaceColor','r');
p2 = plot(data_IT_Exc25.days, data_IT_Exc25.DeathsPDPM_IT_25,'bo','MarkerSize',3,'MarkerFaceColor','b');

p3 = plot(t_fit1_IT_Exc25, exp(y_fit1_IT_Exc25),'r--');
p4 = plot(t_fit2_IT_Exc25, exp(y_fit2_IT_Exc25),'r-.');
plot(t_fit3_IT_Exc25, exp(y_fit3_IT_Exc25),'r-');

p5 = plot(t_fit1_IT_25, exp(y_fit1_IT_25),'b--');
p6 = plot(t_fit2_IT_25, exp(y_fit2_IT_25),'b-.');
plot(t_fit3_IT_25, exp(y_fit3_IT_25),'b-');

ylabel('Deaths per day per million');grid on;box on;
legend([p1 p2 p3 p4 p5 p6],'Italy exc. Lombardy data','Lombardy only data',...
                           ['\alpha_U = ',num2str(aU_IT_Exc25)],...
                           ['\alpha_L = ',num2str(aL_IT_Exc25)],...
                           ['\alpha_U = ',num2str(aU_IT_25)],...
                           ['\alpha_L = ',num2str(aL_IT_25)],...
                           'location','SouthEast')
set(gca,'YScale','log')
title('Deaths per day per million with fits for Italy')
xlim([60 150]);ylim([1e-2 1e2])


%% NEW YORK CITY

data_filename_NYC_boroughs = 'boroughs-case-hosp-death_04_06_2020.csv';
opts = detectImportOptions(data_filename_NYC_boroughs, 'TextType','string');
temp_table = readtable(data_filename_NYC_boroughs,opts);

% Delete irrelevant information
temp_table(:,[2 3 5 6 8 9 11 12 14 15]) = [];
temp_table.Properties.VariableNames{1} = 'date';
temp_table.Properties.VariableNames{2} = 'DeathsPD_NYC_BK';
temp_table.Properties.VariableNames{3} = 'DeathsPD_NYC_BX';
temp_table.Properties.VariableNames{4} = 'DeathsPD_NYC_MN';
temp_table.Properties.VariableNames{5} = 'DeathsPD_NYC_QN';
temp_table.Properties.VariableNames{6} = 'DeathsPD_NYC_SI';

data_NYC = temp_table;
clear opts temp_table data_filename_NYC_boroughs
data_NYC = table2timetable(data_NYC);
data_NYC.date.Format = 'dd-MMM-yyyy';

data_NYC.DeathsPD_NYC = data_NYC.DeathsPD_NYC_BK + data_NYC.DeathsPD_NYC_BX + data_NYC.DeathsPD_NYC_MN + ...
                        data_NYC.DeathsPD_NYC_QN + data_NYC.DeathsPD_NYC_SI;
data_NYC.DeathsPD_NYC_ExcBX = data_NYC.DeathsPD_NYC - data_NYC.DeathsPD_NYC_BX;

data_NYC.DeathsPD_NYC_BK(data_NYC.DeathsPD_NYC_BK<=0) = NaN;
data_NYC.DeathsPD_NYC_BX(data_NYC.DeathsPD_NYC_BX<=0) = NaN;
data_NYC.DeathsPD_NYC_MN(data_NYC.DeathsPD_NYC_MN<=0) = NaN;
data_NYC.DeathsPD_NYC_QN(data_NYC.DeathsPD_NYC_QN<=0) = NaN;
data_NYC.DeathsPD_NYC_SI(data_NYC.DeathsPD_NYC_SI<=0) = NaN;
data_NYC.DeathsPD_NYC(data_NYC.DeathsPD_NYC<=0) = NaN;
data_NYC.DeathsPD_NYC_ExcBX(data_NYC.DeathsPD_NYC_ExcBX<=0) = NaN;

data_NYC.population_NYC_BK = ones(height(data_NYC),1)*2.56e6;
data_NYC.population_NYC_BX = ones(height(data_NYC),1)*1.42e6;
data_NYC.population_NYC_MN = ones(height(data_NYC),1)*1.63e6;
data_NYC.population_NYC_QN = ones(height(data_NYC),1)*2.25e6;
data_NYC.population_NYC_SI = ones(height(data_NYC),1)*0.476e6;
data_NYC.population_NYC = data_NYC.population_NYC_BK + data_NYC.population_NYC_BX + data_NYC.population_NYC_MN + ...
                        data_NYC.population_NYC_QN + data_NYC.population_NYC_SI;
data_NYC.population_NYC_ExcBX = data_NYC.population_NYC - data_NYC.population_NYC_BX;

data_NYC.DeathsPDPM_NYC_BK = (data_NYC.DeathsPD_NYC_BK)./(data_NYC.population_NYC_BK)*1e6;
data_NYC.DeathsPDPM_NYC_BX = (data_NYC.DeathsPD_NYC_BX)./(data_NYC.population_NYC_BX)*1e6;
data_NYC.DeathsPDPM_NYC_MN = (data_NYC.DeathsPD_NYC_MN)./(data_NYC.population_NYC_MN)*1e6;
data_NYC.DeathsPDPM_NYC_QN = (data_NYC.DeathsPD_NYC_QN)./(data_NYC.population_NYC_QN)*1e6;
data_NYC.DeathsPDPM_NYC_SI = (data_NYC.DeathsPD_NYC_SI)./(data_NYC.population_NYC_SI)*1e6;
data_NYC.DeathsPDPM_NYC = (data_NYC.DeathsPD_NYC)./(data_NYC.population_NYC)*1e6;
data_NYC.DeathsPDPM_NYC_ExcBX = (data_NYC.DeathsPD_NYC_ExcBX)./(data_NYC.population_NYC_ExcBX)*1e6;

data_NYC.LOG_DeathsPDPM_NYC_BK = log(data_NYC.DeathsPDPM_NYC_BK);
data_NYC.LOG_DeathsPDPM_NYC_BX = log(data_NYC.DeathsPDPM_NYC_BX);
data_NYC.LOG_DeathsPDPM_NYC_MN = log(data_NYC.DeathsPDPM_NYC_MN);
data_NYC.LOG_DeathsPDPM_NYC_QN = log(data_NYC.DeathsPDPM_NYC_QN);
data_NYC.LOG_DeathsPDPM_NYC_SI = log(data_NYC.DeathsPDPM_NYC_SI);
data_NYC.LOG_DeathsPDPM_NYC = log(data_NYC.DeathsPDPM_NYC);
data_NYC.LOG_DeathsPDPM_NYC_ExcBX = log(data_NYC.DeathsPDPM_NYC_ExcBX);

%% US Data

data_US = OpenCovid_data_full(OpenCovid_data_full.('key')=='US',:);

% Combine US and NY data into a single synochornized timetable
temp1 = timetable(data_US.date, data_US.DeathsPD, data_US.population,'VariableNames',{'DeathsPD_US','population_US'});
temp2 = data_NYC;
data_US_ExcNY = synchronize(temp1, temp2);
clear temp1 temp2
data_US_ExcNY.Properties.DimensionNames{1} = 'date';
data_US_ExcNY.days = datenum(data_US_ExcNY.date) - datenum('01-Jan-2020');

 % Make sure none of the population values are NaN
data_US_ExcNY.population_US(:) = mean(data_US_ExcNY.population_US(~isnan(data_US_ExcNY.population_US)));
data_US_ExcNY.population_NYC_BK(:) = mean(data_US_ExcNY.population_NYC_BK(~isnan(data_US_ExcNY.population_NYC_BK))); 
data_US_ExcNY.population_NYC_BX(:) = mean(data_US_ExcNY.population_NYC_BX(~isnan(data_US_ExcNY.population_NYC_BX))); 
data_US_ExcNY.population_NYC_MN(:) = mean(data_US_ExcNY.population_NYC_MN(~isnan(data_US_ExcNY.population_NYC_MN))); 
data_US_ExcNY.population_NYC_QN(:) = mean(data_US_ExcNY.population_NYC_QN(~isnan(data_US_ExcNY.population_NYC_QN))); 
data_US_ExcNY.population_NYC_SI(:) = mean(data_US_ExcNY.population_NYC_SI(~isnan(data_US_ExcNY.population_NYC_SI))); 
data_US_ExcNY.population_NYC(:) = mean(data_US_ExcNY.population_NYC(~isnan(data_US_ExcNY.population_NYC))); 
data_US_ExcNY.population_NYC_ExcBX(:) = mean(data_US_ExcNY.population_NYC_ExcBX(~isnan(data_US_ExcNY.population_NYC_ExcBX)));

data_US_ExcNY.DeathsPD_US_ExcNYC = data_US_ExcNY.DeathsPD_US - data_US_ExcNY.DeathsPD_NYC; 
data_US_ExcNY.population_US_ExcNYC = data_US_ExcNY.population_US - data_US_ExcNY.population_NYC;

data_US_ExcNY.DeathsPDPM_US = (data_US_ExcNY.DeathsPD_US)./(data_US_ExcNY.population_US)*1e6;
data_US_ExcNY.DeathsPDPM_US_ExcNYC = (data_US_ExcNY.DeathsPD_US_ExcNYC)./(data_US_ExcNY.population_US_ExcNYC)*1e6;

data_US_ExcNY.LOG_DeathsPDPM_US = log( data_US_ExcNY.DeathsPDPM_US );
data_US_ExcNY.LOG_DeathsPDPM_US_ExcNYC = log( data_US_ExcNY.DeathsPDPM_US_ExcNYC );

%%
figure;
subplot(2,2,1);hold all;
plot(data_US_ExcNY.date, data_US_ExcNY.DeathsPD_NYC_BX,'LineWidth',2)
plot(data_US_ExcNY.date, data_US_ExcNY.DeathsPD_NYC,'LineWidth',2)
plot(data_US_ExcNY.date, data_US_ExcNY.DeathsPD_US,'LineWidth',2)
grid on;box on;ylabel('Deaths per day');
legend('The Bronx','New York City (all 5 boroughs)','US total','location','NorthWest')

subplot(2,2,2);hold all;
plot(data_US_ExcNY.date, cumsum(data_US_ExcNY.DeathsPD_NYC_BX,'omitnan'),'LineWidth',2)
plot(data_US_ExcNY.date, cumsum(data_US_ExcNY.DeathsPD_NYC,'omitnan'),'LineWidth',2)
plot(data_US_ExcNY.date, cumsum(data_US_ExcNY.DeathsPD_US,'omitnan'),'LineWidth',2)
plot(data_US_ExcNY.date, cumsum(data_US_ExcNY.DeathsPD_US_ExcNYC,'omitnan'),'LineWidth',2)
plot(data_US_ExcNY.date, cumsum(data_US_ExcNY.DeathsPD_NYC_ExcBX,'omitnan'),'LineWidth',2)
grid on;box on;ylabel('Cumulative Deaths');
legend('The Bronx','New York City (all 5 boroughs)','US total','US exc. New York City','New York City exc. The Bronx','location','NorthWest')

subplot(2,2,3);hold all;
plot(data_US_ExcNY.date, data_US_ExcNY.LOG_DeathsPDPM_NYC_BX)
plot(data_US_ExcNY.date, data_US_ExcNY.LOG_DeathsPDPM_NYC)
plot(data_US_ExcNY.date, data_US_ExcNY.LOG_DeathsPDPM_US)
plot(data_US_ExcNY.date, data_US_ExcNY.LOG_DeathsPDPM_US_ExcNYC)
plot(data_US_ExcNY.date, data_US_ExcNY.LOG_DeathsPDPM_NYC_ExcBX)
grid on;box on;ylabel('Log( Deaths per day )');
legend('The Bronx','New York City (all 5 boroughs)','US total','US exc. New York City','New York City exc. The Bronx','location','SouthEast')

subplot(2,2,4);hold all;
plot(data_US_ExcNY.date, data_US_ExcNY.LOG_DeathsPDPM_NYC_BK)
plot(data_US_ExcNY.date, data_US_ExcNY.LOG_DeathsPDPM_NYC_BX)
plot(data_US_ExcNY.date, data_US_ExcNY.LOG_DeathsPDPM_NYC_MN)
plot(data_US_ExcNY.date, data_US_ExcNY.LOG_DeathsPDPM_NYC_QN)
plot(data_US_ExcNY.date, data_US_ExcNY.LOG_DeathsPDPM_NYC_SI)
plot(data_US_ExcNY.date, data_US_ExcNY.LOG_DeathsPDPM_NYC,'LineWidth',2)
plot(data_US_ExcNY.date, data_US_ExcNY.LOG_DeathsPDPM_NYC_ExcBX,'LineWidth',2)
grid on;box on;ylabel('Log( Deaths per day )');
legend('Brooklyn','The Bronx','Manhattan','Queens','Staten Island','New York City (all 5 boroughs)','New York City exc. The Bronx','location','SouthEast')

%% SEQUENTIAL FITS - US
figure;
subplot(2,3,1)
[fit_res1_NYC, ~, t_fit1_NYC, y_fit1_NYC] = fit_linear_slope(data_US_ExcNY.days, data_US_ExcNY.LOG_DeathsPDPM_NYC, [13:150]);
subplot(2,3,2)
[fit_res2_NYC, ~, t_fit2_NYC, y_fit2_NYC] = fit_linear_slope(data_US_ExcNY.days, data_US_ExcNY.LOG_DeathsPDPM_NYC, [1:35 77:90]);
coeff_values1_NYC = coeffvalues(fit_res1_NYC);
aU_NYC = coeff_values1_NYC(1);
coeff_values2_NYC = coeffvalues(fit_res2_NYC);
aL_NYC = coeff_values2_NYC(1);
subplot(2,3,3)
[fit_res3_NYC, ~, t_fit3_NYC, y_fit3_NYC] = fit_full_log_aU_aL_CON(data_US_ExcNY.days, data_US_ExcNY.LOG_DeathsPDPM_NYC, aU_NYC, aL_NYC, [76 79 80 81]);

subplot(2,3,4)
%[fit_res1_ES_ExcMD, ~, t_fit1_ES_ExcMD, y_fit1_ES_ExcMD] = fit_linear_slope(data_ES_ExcMD.days, data_ES_ExcMD.LOG_DeathsPDPM, [12:150]);
[fit_res1_US_ExcNYC, ~, t_fit1_US_ExcNYC, y_fit1_US_ExcNYC] = fit_linear_slope(data_US_ExcNY.days, data_US_ExcNY.LOG_DeathsPDPM_US_ExcNYC, [1 16:150]);
subplot(2,3,5)
[fit_res2_US_ExcNYC, ~, t_fit2_US_ExcNYC, y_fit2_US_ExcNYC] = fit_linear_slope(data_US_ExcNY.days, data_US_ExcNY.LOG_DeathsPDPM_US_ExcNYC, [1:30 83:100]);
coeff_values1_US_ExcNYC = coeffvalues(fit_res1_US_ExcNYC);
aU_US_ExcNYC = coeff_values1_US_ExcNYC(1);
coeff_values2_US_ExcNYC = coeffvalues(fit_res2_US_ExcNYC);
aL_US_ExcNYC = coeff_values2_US_ExcNYC(1);
subplot(2,3,6)
[fit_res3_US_ExcNYC, ~, t_fit3_US_ExcNYC, y_fit3_US_ExcNYC] = fit_full_log_aU_aL_CON(data_US_ExcNY.days, data_US_ExcNY.LOG_DeathsPDPM_US_ExcNYC, aU_US_ExcNYC, aL_US_ExcNYC, [1 50]);
%[fit_res3_ES_ExcMD, ~, t_fit3_ES_ExcMD, y_fit3_ES_ExcMD] = fit_full_log_aU_aL_CON(data_ES_ExcMD.days, data_ES_ExcMD.LOG_DeathsPDPM, aU_ES_ExcMD, aL_ES_ExcMD, [50]);

subplot(2,3,1);title('NYC (\alpha_U Fit)')
subplot(2,3,2);title('NYC (\alpha_L Fit)')
subplot(2,3,3);title('NYC (Full Log Fit)')
subplot(2,3,4);title('US Exc. NYC (\alpha_L Fit)')
subplot(2,3,5);title('US Exc. NYC (\alpha_U Fit)')
subplot(2,3,6);title('US Exc. NYC (Full Log Fit)')

%% PLOT EVERYTHING FOR US and NYC
figure;
hold all;
p1 = plot(data_US_ExcNY.days, data_US_ExcNY.DeathsPDPM_US_ExcNYC,'ro','MarkerSize',3,'MarkerFaceColor','r');
p2 = plot(data_US_ExcNY.days, data_US_ExcNY.DeathsPDPM_NYC,'bo','MarkerSize',3,'MarkerFaceColor','b');

p3 = plot(t_fit1_US_ExcNYC, exp(y_fit1_US_ExcNYC),'r--');
p4 = plot(t_fit2_US_ExcNYC, exp(y_fit2_US_ExcNYC),'r-.');
plot(t_fit3_US_ExcNYC, exp(y_fit3_US_ExcNYC),'r-');

p5 = plot(t_fit1_NYC, exp(y_fit1_NYC),'b--');
p6 = plot(t_fit2_NYC, exp(y_fit2_NYC),'b-.');
plot(t_fit3_NYC, exp(y_fit3_NYC),'b-');

ylabel('Deaths per day per million');grid on;box on;
legend([p1 p2 p3 p4 p5 p6],'US exc. NYC data','NYC only data',...
                           ['\alpha_U = ',num2str(aU_IT_Exc25)],...
                           ['\alpha_L = ',num2str(aL_IT_Exc25)],...
                           ['\alpha_U = ',num2str(aU_IT_25)],...
                           ['\alpha_L = ',num2str(aL_IT_25)],...
                           'location','SouthEast')
set(gca,'YScale','log')
title('Deaths per day per million with fits for US and NYC')
xlim([60 150]);ylim([1e-2 1e2])
set(gcf,'color','w')


%% ENGLAND AND LONDON

data_filename_UK_regions = 'COVID-19-total-announced-deaths-22-May-2020.xlsx';

%%% Import and create data_full table if it doesnt already exist: %%%%%%%%%
warning('off','MATLAB:table:ModifiedAndSavedVarnames')
temp_table = readtable(data_filename_UK_regions,'Sheet','Tab1 Deaths by region');
warning('on','MATLAB:table:ModifiedAndSavedVarnames')

% Delete irrelevant information
temp_table([1:13 16],:) = [];
temp_table(:,[2 3 82:end]) = [];

% Extract Dates and Convert them to Datetime Objects 
Date = datetime(table2array(temp_table(1,2:end)),'InputFormat','dd/MM/yyyy')';
temp_table(1,:) = [];
temp_table(:,1) = [];


date_table = table(Date,'VariableNames',{'Date'});
data_table = array2table(str2double(table2array(temp_table)).');
temp_table = [date_table,data_table];
temp_table(:,[3 5:end]) = [];

temp_table.Properties.VariableNames{1} = 'date';
temp_table.Properties.VariableNames{2} = 'DeathsPD_EN';
temp_table.Properties.VariableNames{3} = 'DeathsPD_EN_LDN';

data_EN_ExcLDN = table2timetable(temp_table);
clear date_table data_table data_filename_UK_regions temp_table Date

data_EN_ExcLDN.date.Format = 'dd-MMM-yyyy';
data_EN_ExcLDN.days = datenum(data_EN_ExcLDN.date) - datenum('01-Jan-2020');


data_EN_ExcLDN.DeathsPD_EN_ExcLDN = data_EN_ExcLDN.DeathsPD_EN - data_EN_ExcLDN.DeathsPD_EN_LDN;
data_EN_ExcLDN.DeathsPD_EN(data_EN_ExcLDN.DeathsPD_EN==0) = NaN;
data_EN_ExcLDN.DeathsPD_EN_LDN(data_EN_ExcLDN.DeathsPD_EN_LDN==0) = NaN;
data_EN_ExcLDN.DeathsPD_EN_ExcLDN(data_EN_ExcLDN.DeathsPD_EN_ExcLDN==0) = NaN;

data_EN_ExcLDN.population_EN = ones(height(data_EN_ExcLDN),1)*56e6;
data_EN_ExcLDN.population_EN_LDN = ones(height(data_EN_ExcLDN),1)*8.98e6;
data_EN_ExcLDN.population_EN_ExcLDN = data_EN_ExcLDN.population_EN - data_EN_ExcLDN.population_EN_LDN;

data_EN_ExcLDN.DeathsPDPM_EN = (data_EN_ExcLDN.DeathsPD_EN)./(data_EN_ExcLDN.population_EN)*1e6;
data_EN_ExcLDN.DeathsPDPM_EN_LDN = (data_EN_ExcLDN.DeathsPD_EN_LDN)./(data_EN_ExcLDN.population_EN_LDN)*1e6;
data_EN_ExcLDN.DeathsPDPM_EN_ExcLDN = (data_EN_ExcLDN.DeathsPD_EN_ExcLDN)./(data_EN_ExcLDN.population_EN_ExcLDN)*1e6;

data_EN_ExcLDN.LOG_DeathsPDPM_EN = log( data_EN_ExcLDN.DeathsPDPM_EN );
data_EN_ExcLDN.LOG_DeathsPDPM_EN_LDN = log( data_EN_ExcLDN.DeathsPDPM_EN_LDN );
data_EN_ExcLDN.LOG_DeathsPDPM_EN_ExcLDN = log( data_EN_ExcLDN.DeathsPDPM_EN_ExcLDN );

%% SEQUENTIAL FITS - ENGLAND
figure;
subplot(2,3,1)
[fit_res1_EN_LDN, ~, t_fit1_EN_LDN, y_fit1_EN_LDN] = fit_linear_slope(data_EN_ExcLDN.days, data_EN_ExcLDN.LOG_DeathsPDPM_EN_LDN, [14:150]);
subplot(2,3,2)
[fit_res2_EN_LDN, ~, t_fit2_EN_LDN, y_fit2_EN_LDN] = fit_linear_slope(data_EN_ExcLDN.days, data_EN_ExcLDN.LOG_DeathsPDPM_EN_LDN, [1:40 77:90]);
coeff_values1_EN_LDN = coeffvalues(fit_res1_EN_LDN);
aU_EN_LDN = coeff_values1_EN_LDN(1);
coeff_values2_EN_LDN = coeffvalues(fit_res2_EN_LDN);
aL_EN_LDN = coeff_values2_EN_LDN(1);
subplot(2,3,3)
[fit_res3_EN_LDN, ~, t_fit3_EN_LDN, y_fit3_EN_LDN] = fit_full_log_aU_aL_CON(data_EN_ExcLDN.days, data_EN_ExcLDN.LOG_DeathsPDPM_EN_LDN, aU_EN_LDN, aL_EN_LDN, [50]);

subplot(2,3,4)
[fit_res1_EN_ExcLDN, ~, t_fit1_EN_ExcLDN, y_fit1_EN_ExcLDN] = fit_linear_slope(data_EN_ExcLDN.days, data_EN_ExcLDN.LOG_DeathsPDPM_EN_ExcLDN, [1 20:150]);
subplot(2,3,5)
[fit_res2_EN_ExcLDN, ~, t_fit2_EN_ExcLDN, y_fit2_EN_ExcLDN] = fit_linear_slope(data_EN_ExcLDN.days, data_EN_ExcLDN.LOG_DeathsPDPM_EN_ExcLDN, [1:40 83:100]);
coeff_values1_EN_ExcLDN = coeffvalues(fit_res1_EN_ExcLDN);
aU_EN_ExcLDN = coeff_values1_EN_ExcLDN(1);
coeff_values2_EN_ExcLDN = coeffvalues(fit_res2_EN_ExcLDN);
aL_EN_ExcLDN = coeff_values2_EN_ExcLDN(1);
subplot(2,3,6)
[fit_res3_EN_ExcLDN, ~, t_fit3_EN_ExcLDN, y_fit3_EN_ExcLDN] = fit_full_log_aU_aL_CON(data_EN_ExcLDN.days, data_EN_ExcLDN.LOG_DeathsPDPM_EN_ExcLDN, aU_EN_ExcLDN, aL_EN_ExcLDN, [1 50]);


subplot(2,3,1);title('London (\alpha_U Fit)')
subplot(2,3,2);title('London (\alpha_L Fit)')
subplot(2,3,3);title('London (Full Log Fit)')
subplot(2,3,4);title('England Exc. London (\alpha_L Fit)')
subplot(2,3,5);title('England Exc. London (\alpha_U Fit)')
subplot(2,3,6);title('England Exc. London (Full Log Fit)')

% PLOT EVERYTHING FOR England AND London
figure;
hold all;
p1 = plot(data_EN_ExcLDN.days, data_EN_ExcLDN.DeathsPDPM_EN_ExcLDN,'ro','MarkerSize',3,'MarkerFaceColor','r');
p2 = plot(data_EN_ExcLDN.days, data_EN_ExcLDN.DeathsPDPM_EN_LDN,'bo','MarkerSize',3,'MarkerFaceColor','b');

p3 = plot(t_fit1_EN_ExcLDN, exp(y_fit1_EN_ExcLDN),'r--');
p4 = plot(t_fit2_EN_ExcLDN, exp(y_fit2_EN_ExcLDN),'r-.');
plot(t_fit3_EN_ExcLDN, exp(y_fit3_EN_ExcLDN),'r-');

p5 = plot(t_fit1_EN_LDN, exp(y_fit1_EN_LDN),'b--');
p6 = plot(t_fit2_EN_LDN, exp(y_fit2_EN_LDN),'b-.');
plot(t_fit3_EN_LDN, exp(y_fit3_EN_LDN),'b-');

ylabel('Deaths per day per million');grid on;box on;
legend([p1 p2 p3 p4 p5 p6],'England exc. London data','London only data',...
                           ['\alpha_U = ',num2str(aU_EN_ExcLDN)],...
                           ['\alpha_L = ',num2str(aL_EN_ExcLDN)],...
                           ['\alpha_U = ',num2str(aU_EN_LDN)],...
                           ['\alpha_L = ',num2str(aL_EN_LDN)],...
                           'location','SouthEast')
set(gca,'YScale','log')
title('Deaths per day per million with fits for England and London')
xlim([60 150]);ylim([1e-2 1e2])
set(gcf,'color','w')
