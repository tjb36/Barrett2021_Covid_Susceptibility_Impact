%%% Produces the curvefit objects "fit_res_TS_XXX", after fitting a
%%% modified sigmoid function to each of the country/metro Google Transit
%%% Station data. E.g. for Spain the results are stored in "fit_res_TS_ES"
%%% and for Madrid they are stored in "fit_res_TS_MD".

clear;clc;close all;
load('DATA.mat') % Import file containing data for each region

%% PLOT TRANSIT STATION GOOGLE DATA FOR EACH METRO/COUNTRY
figure;
subplot(2,3,1);hold all;
plot(data_ES_ExcMD.days, data_ES_ExcMD.TS_MD)
plot(data_ES_ExcMD.days, data_ES_ExcMD.TS_ES)
legend('Madrid','Spain','location','NorthEast');grid on;box on;ylabel('Transit [%]')
title('Spain/Madrid')

subplot(2,3,2);hold all;
plot(data_IT_Exc25.date, data_IT_Exc25.TS_25)
plot(data_IT_Exc25.date, data_IT_Exc25.TS_IT)
legend('Lombardy','Italy','location','NorthEast');grid on;box on;ylabel('Transit [%]')
title('Italy/Lombardy')

subplot(2,3,3);hold all;
plot(data_US_ExcNY.date, data_US_ExcNY.TS_NY)
plot(data_US_ExcNY.date, data_US_ExcNY.TS_US)
legend('New York State','U.S.','location','NorthEast');grid on;box on;ylabel('Transit [%]')
title('US/NY State')

subplot(2,3,4);hold all;
plot(data_EN_ExcLDN.date, data_EN_ExcLDN.TS_LDN)
plot(data_EN_ExcLDN.date, data_EN_ExcLDN.TS_EN)
legend('London','U.K.','location','NorthEast');grid on;box on;ylabel('Transit [%]')
title('UK/London')

subplot(2,3,5);hold all;
plot(data_ES_ExcMD.date, data_ES_ExcMD.TS_MD)
plot(data_IT_Exc25.date, data_IT_Exc25.TS_25)
plot(data_US_ExcNY.date, data_US_ExcNY.TS_NY)
plot(data_EN_ExcLDN.date, data_EN_ExcLDN.TS_LDN)
legend('Madrid','Lombardy','New York State','London','location','NorthEast');grid on;box on;ylabel('Transit [%]')
title('Metros')

subplot(2,3,6);hold all;
plot(data_US_ExcNY.date, data_US_ExcNY.TS_BK)
plot(data_US_ExcNY.date, data_US_ExcNY.TS_BX)
plot(data_US_ExcNY.date, data_US_ExcNY.TS_MN)
plot(data_US_ExcNY.date, data_US_ExcNY.TS_QN)
plot(data_US_ExcNY.date, data_US_ExcNY.TS_SI)
plot(data_US_ExcNY.date, data_US_ExcNY.TS_NY)
legend('Brooklyn','The Bronx','Manhattan','Queens','Staten Island','New York State','location','NorthEast');grid on;box on;ylabel('Transit [%]')
title('Various Regions of NY')

%% FIT MODIFIED SIGMOID TO TRANSIT STATION GOOGLE DATA FOR EACH METRO/COUNTRY
%% SPAIN
figure;
subplot(1,3,1);hold all;
[fit_res_TS_ES, ~, t_fit_TS_ES, y_fit_TS_ES] = fit_sigmoid(data_ES_ExcMD.days, data_ES_ExcMD.TS_ES, [60:200]);
title('Spain')
subplot(1,3,2);hold all;
[fit_res_TS_MD, ~, t_fit_TS_MD, y_fit_TS_MD] = fit_sigmoid(data_ES_ExcMD.days, data_ES_ExcMD.TS_MD, [60:200]);
title('Madrid')

subplot(1,3,3);hold all;
plot(data_ES_ExcMD.days, data_ES_ExcMD.TS_ES,'ro','MarkerSize',3,'MarkerFaceColor','r');
plot(data_ES_ExcMD.days, data_ES_ExcMD.TS_MD,'bo','MarkerSize',3,'MarkerFaceColor','b');
plot(t_fit_TS_ES,        y_fit_TS_ES,'r-')
plot(t_fit_TS_MD,        y_fit_TS_MD,'b-')

legend('Spain','Madrid','location','NorthEast');grid on;box on;ylabel('Transit [%]');

%% ITALY
figure;
subplot(1,3,1);hold all;
[fit_res_TS_IT, ~, t_fit_TS_IT, y_fit_TS_IT] = fit_sigmoid(data_IT_Exc25.days, data_IT_Exc25.TS_IT, [10:18 60:200]);
title('Italy')
subplot(1,3,2);hold all;
[fit_res_TS_25, ~, t_fit_TS_25, y_fit_TS_25] = fit_sigmoid(data_IT_Exc25.days, data_IT_Exc25.TS_25, [9:17 60:200]);
title('Lombardy')

subplot(1,3,3);hold all;
plot(data_IT_Exc25.days, data_IT_Exc25.TS_IT,'ro','MarkerSize',3,'MarkerFaceColor','r');
plot(data_IT_Exc25.days, data_IT_Exc25.TS_25,'bo','MarkerSize',3,'MarkerFaceColor','b');
plot(t_fit_TS_IT,        y_fit_TS_IT,'r-')
plot(t_fit_TS_25,        y_fit_TS_25,'b-')

legend('Italy','Lombardy','location','NorthEast');grid on;box on;ylabel('Transit [%]');

%% US
figure;
subplot(1,3,1);hold all;
[fit_res_TS_US, ~, t_fit_TS_US, y_fit_TS_US] = fit_sigmoid(data_US_ExcNY.days, data_US_ExcNY.TS_US, [60:200]);
title('US')
subplot(1,3,2);hold all;
[fit_res_TS_NY, ~, t_fit_TS_NY, y_fit_TS_NY] = fit_sigmoid(data_US_ExcNY.days, data_US_ExcNY.TS_NY, [60:200]);
title('New York State')

subplot(1,3,3);hold all;
plot(data_US_ExcNY.days, data_US_ExcNY.TS_US,'ro','MarkerSize',3,'MarkerFaceColor','r');
plot(data_US_ExcNY.days, data_US_ExcNY.TS_NY,'bo','MarkerSize',3,'MarkerFaceColor','b');
plot(t_fit_TS_US,        y_fit_TS_US,'r-')
plot(t_fit_TS_NY,        y_fit_TS_NY,'b-')

legend('US','New York State','location','NorthEast');grid on;box on;ylabel('Transit [%]');

%% UK
figure;
subplot(1,3,1);hold all;
[fit_res_TS_EN, ~, t_fit_TS_EN, y_fit_TS_EN] = fit_sigmoid(data_EN_ExcLDN.days, data_EN_ExcLDN.TS_EN, [60:200]);
title('UK')
subplot(1,3,2);hold all;
[fit_res_TS_LDN, ~, t_fit_TS_LDN, y_fit_TS_LDN] = fit_sigmoid(data_EN_ExcLDN.days, data_EN_ExcLDN.TS_LDN, [60:200]);
title('London')

subplot(1,3,3);hold all;
plot(data_EN_ExcLDN.days, data_EN_ExcLDN.TS_EN,'ro','MarkerSize',3,'MarkerFaceColor','r');
plot(data_EN_ExcLDN.days, data_EN_ExcLDN.TS_LDN,'bo','MarkerSize',3,'MarkerFaceColor','b');
plot(t_fit_TS_EN,         y_fit_TS_EN,'r-')
plot(t_fit_TS_LDN,        y_fit_TS_LDN,'b-')

legend('UK','London','location','NorthEast');grid on;box on;ylabel('Transit [%]');


%% PLOTTING ALL TRANSIT STATION SIGMOID FITS TOGETHER
xlims = [45 100];
figure;
subplot(2,2,1);hold all;
plot(data_ES_ExcMD.days, data_ES_ExcMD.TS_ES,'ro','MarkerSize',3,'MarkerFaceColor','r');
plot(data_ES_ExcMD.days, data_ES_ExcMD.TS_MD,'bo','MarkerSize',3,'MarkerFaceColor','b');
plot(t_fit_TS_ES,        y_fit_TS_ES,'r-')
plot(t_fit_TS_MD,        y_fit_TS_MD,'b-')
legend('Spain','Madrid','location','NorthEast');grid on;box on;ylabel('Transit [%]');
xlim(xlims)

subplot(2,2,2);hold all;
plot(data_IT_Exc25.days, data_IT_Exc25.TS_IT,'ro','MarkerSize',3,'MarkerFaceColor','r');
plot(data_IT_Exc25.days, data_IT_Exc25.TS_25,'bo','MarkerSize',3,'MarkerFaceColor','b');
plot(t_fit_TS_IT,        y_fit_TS_IT,'r-')
plot(t_fit_TS_25,        y_fit_TS_25,'b-')
legend('Italy','Lombardy','location','NorthEast');grid on;box on;ylabel('Transit [%]');
xlim(xlims)

subplot(2,2,3);hold all;
plot(data_US_ExcNY.days, data_US_ExcNY.TS_US,'ro','MarkerSize',3,'MarkerFaceColor','r');
plot(data_US_ExcNY.days, data_US_ExcNY.TS_NY,'bo','MarkerSize',3,'MarkerFaceColor','b');
plot(t_fit_TS_US,        y_fit_TS_US,'r-')
plot(t_fit_TS_NY,        y_fit_TS_NY,'b-')
legend('US','New York State','location','NorthEast');grid on;box on;ylabel('Transit [%]');
xlim(xlims)

subplot(2,2,4);hold all;
plot(data_EN_ExcLDN.days, data_EN_ExcLDN.TS_EN,'ro','MarkerSize',3,'MarkerFaceColor','r');
plot(data_EN_ExcLDN.days, data_EN_ExcLDN.TS_LDN,'bo','MarkerSize',3,'MarkerFaceColor','b');
plot(t_fit_TS_EN,         y_fit_TS_EN,'r-')
plot(t_fit_TS_LDN,        y_fit_TS_LDN,'b-')
legend('UK','London','location','NorthEast');grid on;box on;ylabel('Transit [%]');
xlim(xlims)


%% PLOT STRINGENCY INDEX FOR EACH COUNTRY
figure;hold all;
plot(data_ES.days, data_ES.stringency_index)
plot(data_IT.days, data_IT.stringency_index)
plot(data_US.days, data_US.stringency_index)
plot(data_EN_ExcLDN.days, data_EN_ExcLDN.stringency_index)
legend('Spain','Italy','United States','UK','location','NorthWest');grid on;box on;ylabel('Stringency Index [%]')
set(gcf,'color','w');set(gca,'FontName','Gill Sans MT','FontSize',12)