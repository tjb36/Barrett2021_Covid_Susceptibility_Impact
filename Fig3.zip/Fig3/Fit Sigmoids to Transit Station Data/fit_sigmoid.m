function [fitresult, gof, t_fit, y_fit] = fit_sigmoid(x, y, exc_indices)

[xData, yData] = prepareCurveData(x,y);

ft = fittype( 'U - (U - L)./( 1 + exp( -(x-t0)/W ) )', 'independent', 'x', 'dependent', 'y' );

exc_indices(exc_indices > length(xData)) = [];
excludedPoints = excludedata( xData, yData, 'Indices', exc_indices);

opts = fitoptions('Method','NonlinearLeastSquares');
opts.StartPoint = [-100 0 5 80];
opts.Exclude = excludedPoints;

[fitresult, gof] = fit(xData,yData,ft,opts);
coeff_values = coeffvalues(fitresult);

t_fit = linspace(0,200,1000);
y_fit = coeff_values(2) - (coeff_values(2) - coeff_values(1))./( 1 + exp( -(t_fit-coeff_values(4))/coeff_values(3) ) );


%Plot fit with data.
h = plot( fitresult, xData, yData, excludedPoints,'r+' );
legend( h, 'Data', 'Excluded Points', ['t0 = ',num2str(coeff_values(4))], 'Location', 'NorthEast' );
% Label axes
xlabel x
ylabel y
grid on
%ylim([-5 5])
end