clear;clc;close all;
load('DATA.mat')


%% SEQUENTIAL FITS - SPAIN AND MADRID
figure;
subplot(2,3,1)
[fit_res1_ES_MD, ~, t_fit1_ES_MD, y_fit1_ES_MD] = fit_linear_slope(data_ES_ExcMD.days, data_ES_ExcMD.LOG_DeathsPDPM_ES_MD, [13:150]);
subplot(2,3,2)
[fit_res2_ES_MD, ~, t_fit2_ES_MD, y_fit2_ES_MD] = fit_linear_slope(data_ES_ExcMD.days, data_ES_ExcMD.LOG_DeathsPDPM_ES_MD, [1:35 76 79 80 81]);
coeff_values1_ES_MD = coeffvalues(fit_res1_ES_MD);
aU_ES_MD = coeff_values1_ES_MD(1);
coeff_values2_ES_MD = coeffvalues(fit_res2_ES_MD);
aL_ES_MD = coeff_values2_ES_MD(1);
subplot(2,3,3)
[fit_res3_ES_MD, ~, t_fit3_ES_MD, y_fit3_ES_MD] = fit_full_log_aU_aL_CON(data_ES_ExcMD.days, data_ES_ExcMD.LOG_DeathsPDPM_ES_MD, aU_ES_MD, aL_ES_MD, [76 79 80 81]);

subplot(2,3,4)
[fit_res1_ES_ExcMD, ~, t_fit1_ES_ExcMD, y_fit1_ES_ExcMD] = fit_linear_slope(data_ES_ExcMD.days, data_ES_ExcMD.LOG_DeathsPDPM_ES_ExcMD, [1:6 12:150]);
subplot(2,3,5)
[fit_res2_ES_ExcMD, ~, t_fit2_ES_ExcMD, y_fit2_ES_ExcMD] = fit_linear_slope(data_ES_ExcMD.days, data_ES_ExcMD.LOG_DeathsPDPM_ES_ExcMD, [1:20 63:80]);
coeff_values1_ES_ExcMD = coeffvalues(fit_res1_ES_ExcMD);
aU_ES_ExcMD = coeff_values1_ES_ExcMD(1);
coeff_values2_ES_ExcMD = coeffvalues(fit_res2_ES_ExcMD);
aL_ES_ExcMD = coeff_values2_ES_ExcMD(1);
subplot(2,3,6)
[fit_res3_ES_ExcMD, ~, t_fit3_ES_ExcMD, y_fit3_ES_ExcMD] = fit_full_log_aU_aL_CON(data_ES_ExcMD.days, data_ES_ExcMD.LOG_DeathsPDPM_ES_ExcMD, aU_ES_ExcMD, aL_ES_ExcMD, [1:6 50]);

subplot(2,3,1);title('Madrid (\alpha_U Fit)')
subplot(2,3,2);title('Madrid (\alpha_L Fit)')
subplot(2,3,3);title('Madrid (Full Log Fit)')
subplot(2,3,4);title('Spain Exc. Madrid (\alpha_L Fit)')
subplot(2,3,5);title('Spain Exc. Madrid (\alpha_U Fit)')
subplot(2,3,6);title('Spain Exc. Madrid (Full Log Fit)')


figure;
hold all;
p1 = plot(data_ES_ExcMD.days, data_ES_ExcMD.DeathsPDPM_ES_ExcMD,'ro','MarkerSize',3,'MarkerFaceColor','r');
p2 = plot(data_ES_ExcMD.days, data_ES_ExcMD.DeathsPDPM_ES_MD,'bo','MarkerSize',3,'MarkerFaceColor','b');

p3 = plot(t_fit1_ES_ExcMD, exp(y_fit1_ES_ExcMD),'r--');
p4 = plot(t_fit2_ES_ExcMD, exp(y_fit2_ES_ExcMD),'r-.');
plot(t_fit3_ES_ExcMD, exp(y_fit3_ES_ExcMD),'r-');

p5 = plot(t_fit1_ES_MD, exp(y_fit1_ES_MD),'b--');
p6 = plot(t_fit2_ES_MD, exp(y_fit2_ES_MD),'b-.');
plot(t_fit3_ES_MD, exp(y_fit3_ES_MD),'b-');

ylabel('Deaths per day per million');grid on;box on;
legend([p1 p2 p3 p4 p5 p6],'Spain exc. Madrid data','Madrid only data',...
                           ['\alpha_U = ',num2str(aU_ES_ExcMD)],...
                           ['\alpha_L = ',num2str(aL_ES_ExcMD)],...
                           ['\alpha_U = ',num2str(aU_ES_MD)],...
                           ['\alpha_L = ',num2str(aL_ES_MD)],...
                           'location','SouthEast')
set(gca,'YScale','log')
title('Deaths per day per million with fits for Spain')
xlim([60 150]);ylim([1e-2 1e2])

%% SEQUENTIAL FITS - ITALY AND LOMBARDY
figure;
subplot(2,3,1)
[fit_res1_IT_25, ~, t_fit1_IT_25, y_fit1_IT_25] = fit_linear_slope(data_IT_Exc25.days, data_IT_Exc25.LOG_DeathsPDPM_IT_25, [13:150]);
subplot(2,3,2)
[fit_res2_IT_25, ~, t_fit2_IT_25, y_fit2_IT_25] = fit_linear_slope(data_IT_Exc25.days, data_IT_Exc25.LOG_DeathsPDPM_IT_25, [1:35 76 79 80 81]);
coeff_values1_IT_25 = coeffvalues(fit_res1_IT_25);
aU_IT_25 = coeff_values1_IT_25(1);
coeff_values2_IT_25 = coeffvalues(fit_res2_IT_25);
aL_IT_25 = coeff_values2_IT_25(1);
subplot(2,3,3)
[fit_res3_IT_25, ~, t_fit3_IT_25, y_fit3_IT_25] = fit_full_log_aU_aL_CON(data_IT_Exc25.days, data_IT_Exc25.LOG_DeathsPDPM_IT_25, aU_IT_25, aL_IT_25, [76 79 80 81]);

subplot(2,3,4)
[fit_res1_IT_Exc25, ~, t_fit1_IT_Exc25, y_fit1_IT_Exc25] = fit_linear_slope(data_IT_Exc25.days, data_IT_Exc25.LOG_DeathsPDPM_IT_Exc25, [1 16:150]);
subplot(2,3,5)
[fit_res2_IT_Exc25, ~, t_fit2_IT_Exc25, y_fit2_IT_Exc25] = fit_linear_slope(data_IT_Exc25.days, data_IT_Exc25.LOG_DeathsPDPM_IT_Exc25, [1:30 83:100]);
coeff_values1_IT_Exc25 = coeffvalues(fit_res1_IT_Exc25);
aU_IT_Exc25 = coeff_values1_IT_Exc25(1);
coeff_values2_IT_Exc25 = coeffvalues(fit_res2_IT_Exc25);
aL_IT_Exc25 = coeff_values2_IT_Exc25(1);
subplot(2,3,6)
[fit_res3_IT_Exc25, ~, t_fit3_IT_Exc25, y_fit3_IT_Exc25] = fit_full_log_aU_aL_CON(data_IT_Exc25.days, data_IT_Exc25.LOG_DeathsPDPM_IT_Exc25, aU_IT_Exc25, aL_IT_Exc25, [1 50]);

subplot(2,3,1);title('Lombardy (\alpha_U Fit)')
subplot(2,3,2);title('Lombardy (\alpha_L Fit)')
subplot(2,3,3);title('Lombardy (Full Log Fit)')
subplot(2,3,4);title('Italy Exc. Lombardy (\alpha_L Fit)')
subplot(2,3,5);title('Italy Exc. Lombardy (\alpha_U Fit)')
subplot(2,3,6);title('Italy Exc. Lombardy (Full Log Fit)')

figure;
hold all;
p1 = plot(data_IT_Exc25.days, data_IT_Exc25.DeathsPDPM_IT_Exc25,'ro','MarkerSize',3,'MarkerFaceColor','r');
p2 = plot(data_IT_Exc25.days, data_IT_Exc25.DeathsPDPM_IT_25,'bo','MarkerSize',3,'MarkerFaceColor','b');

p3 = plot(t_fit1_IT_Exc25, exp(y_fit1_IT_Exc25),'r--');
p4 = plot(t_fit2_IT_Exc25, exp(y_fit2_IT_Exc25),'r-.');
plot(t_fit3_IT_Exc25, exp(y_fit3_IT_Exc25),'r-');

p5 = plot(t_fit1_IT_25, exp(y_fit1_IT_25),'b--');
p6 = plot(t_fit2_IT_25, exp(y_fit2_IT_25),'b-.');
plot(t_fit3_IT_25, exp(y_fit3_IT_25),'b-');

ylabel('Deaths per day per million');grid on;box on;
legend([p1 p2 p3 p4 p5 p6],'Italy exc. Lombardy data','Lombardy only data',...
                           ['\alpha_U = ',num2str(aU_IT_Exc25)],...
                           ['\alpha_L = ',num2str(aL_IT_Exc25)],...
                           ['\alpha_U = ',num2str(aU_IT_25)],...
                           ['\alpha_L = ',num2str(aL_IT_25)],...
                           'location','SouthEast')
set(gca,'YScale','log')
title('Deaths per day per million with fits for Italy')
xlim([60 150]);ylim([1e-2 1e2])

%% SEQUENTIAL FITS - US AND NYC
figure;
subplot(2,3,1)
[fit_res1_US_NYC, ~, t_fit1_US_NYC, y_fit1_US_NYC] = fit_linear_slope(data_US_ExcNY.days, data_US_ExcNY.LOG_DeathsPDPM_US_NYC, [13:150]);
subplot(2,3,2)
[fit_res2_US_NYC, ~, t_fit2_US_NYC, y_fit2_US_NYC] = fit_linear_slope(data_US_ExcNY.days, data_US_ExcNY.LOG_DeathsPDPM_US_NYC, [1:35 77:90]);
coeff_values1_US_NYC = coeffvalues(fit_res1_US_NYC);
aU_US_NYC = coeff_values1_US_NYC(1);
coeff_values2_US_NYC = coeffvalues(fit_res2_US_NYC);
aL_US_NYC = coeff_values2_US_NYC(1);
subplot(2,3,3)
[fit_res3_US_NYC, ~, t_fit3_US_NYC, y_fit3_US_NYC] = fit_full_log_aU_aL_CON(data_US_ExcNY.days, data_US_ExcNY.LOG_DeathsPDPM_US_NYC, aU_US_NYC, aL_US_NYC, [76 79 80 81]);

subplot(2,3,4)
[fit_res1_US_ExcNYC, ~, t_fit1_US_ExcNYC, y_fit1_US_ExcNYC] = fit_linear_slope(data_US_ExcNY.days, data_US_ExcNY.LOG_DeathsPDPM_US_ExcNYC, [1 16:150]);
subplot(2,3,5)
[fit_res2_US_ExcNYC, ~, t_fit2_US_ExcNYC, y_fit2_US_ExcNYC] = fit_linear_slope(data_US_ExcNY.days, data_US_ExcNY.LOG_DeathsPDPM_US_ExcNYC, [1:30 83:100]);
coeff_values1_US_ExcNYC = coeffvalues(fit_res1_US_ExcNYC);
aU_US_ExcNYC = coeff_values1_US_ExcNYC(1);
coeff_values2_US_ExcNYC = coeffvalues(fit_res2_US_ExcNYC);
aL_US_ExcNYC = coeff_values2_US_ExcNYC(1);
subplot(2,3,6)
[fit_res3_US_ExcNYC, ~, t_fit3_US_ExcNYC, y_fit3_US_ExcNYC] = fit_full_log_aU_aL_CON(data_US_ExcNY.days, data_US_ExcNY.LOG_DeathsPDPM_US_ExcNYC, aU_US_ExcNYC, aL_US_ExcNYC, [1 50]);

subplot(2,3,1);title('NYC (\alpha_U Fit)')
subplot(2,3,2);title('NYC (\alpha_L Fit)')
subplot(2,3,3);title('NYC (Full Log Fit)')
subplot(2,3,4);title('US Exc. NYC (\alpha_L Fit)')
subplot(2,3,5);title('US Exc. NYC (\alpha_U Fit)')
subplot(2,3,6);title('US Exc. NYC (Full Log Fit)')

figure;
hold all;
p1 = plot(data_US_ExcNY.days, data_US_ExcNY.DeathsPDPM_US_ExcNYC,'ro','MarkerSize',3,'MarkerFaceColor','r');
p2 = plot(data_US_ExcNY.days, data_US_ExcNY.DeathsPDPM_US_NYC,'bo','MarkerSize',3,'MarkerFaceColor','b');
p3 = plot(t_fit1_US_ExcNYC, exp(y_fit1_US_ExcNYC),'r--');
p4 = plot(t_fit2_US_ExcNYC, exp(y_fit2_US_ExcNYC),'r-.');
plot(t_fit3_US_ExcNYC, exp(y_fit3_US_ExcNYC),'r-');
p5 = plot(t_fit1_US_NYC, exp(y_fit1_US_NYC),'b--');
p6 = plot(t_fit2_US_NYC, exp(y_fit2_US_NYC),'b-.');
plot(t_fit3_US_NYC, exp(y_fit3_US_NYC),'b-');

ylabel('Deaths per day per million');grid on;box on;
legend([p1 p2 p3 p4 p5 p6],'US exc. NYC data','NYC only data',...
                           ['\alpha_U = ',num2str(aU_US_ExcNYC)],...
                           ['\alpha_L = ',num2str(aL_US_ExcNYC)],...
                           ['\alpha_U = ',num2str(aU_US_NYC)],...
                           ['\alpha_L = ',num2str(aL_US_NYC)],...
                           'location','SouthEast')
set(gca,'YScale','log')
title('Deaths per day per million with fits for US and NYC')
xlim([60 150]);ylim([1e-2 1e2])
set(gcf,'color','w')

%% SEQUENTIAL FITS - ENGLAND AND LONDON
figure;
subplot(2,3,1)
[fit_res1_EN_LDN, ~, t_fit1_EN_LDN, y_fit1_EN_LDN] = fit_linear_slope(data_EN_ExcLDN.days, data_EN_ExcLDN.LOG_DeathsPDPM_EN_LDN, [14:150]);
subplot(2,3,2)
[fit_res2_EN_LDN, ~, t_fit2_EN_LDN, y_fit2_EN_LDN] = fit_linear_slope(data_EN_ExcLDN.days, data_EN_ExcLDN.LOG_DeathsPDPM_EN_LDN, [1:40 77:90]);
coeff_values1_EN_LDN = coeffvalues(fit_res1_EN_LDN);
aU_EN_LDN = coeff_values1_EN_LDN(1);
coeff_values2_EN_LDN = coeffvalues(fit_res2_EN_LDN);
aL_EN_LDN = coeff_values2_EN_LDN(1);
subplot(2,3,3)
[fit_res3_EN_LDN, ~, t_fit3_EN_LDN, y_fit3_EN_LDN] = fit_full_log_aU_aL_CON(data_EN_ExcLDN.days, data_EN_ExcLDN.LOG_DeathsPDPM_EN_LDN, aU_EN_LDN, aL_EN_LDN, [50]);

subplot(2,3,4)
[fit_res1_EN_ExcLDN, ~, t_fit1_EN_ExcLDN, y_fit1_EN_ExcLDN] = fit_linear_slope(data_EN_ExcLDN.days, data_EN_ExcLDN.LOG_DeathsPDPM_EN_ExcLDN, [1 20:150]);
subplot(2,3,5)
[fit_res2_EN_ExcLDN, ~, t_fit2_EN_ExcLDN, y_fit2_EN_ExcLDN] = fit_linear_slope(data_EN_ExcLDN.days, data_EN_ExcLDN.LOG_DeathsPDPM_EN_ExcLDN, [1:40 83:100]);
coeff_values1_EN_ExcLDN = coeffvalues(fit_res1_EN_ExcLDN);
aU_EN_ExcLDN = coeff_values1_EN_ExcLDN(1);
coeff_values2_EN_ExcLDN = coeffvalues(fit_res2_EN_ExcLDN);
aL_EN_ExcLDN = coeff_values2_EN_ExcLDN(1);
subplot(2,3,6)
[fit_res3_EN_ExcLDN, ~, t_fit3_EN_ExcLDN, y_fit3_EN_ExcLDN] = fit_full_log_aU_aL_CON(data_EN_ExcLDN.days, data_EN_ExcLDN.LOG_DeathsPDPM_EN_ExcLDN, aU_EN_ExcLDN, aL_EN_ExcLDN, [1 50]);


subplot(2,3,1);title('London (\alpha_U Fit)')
subplot(2,3,2);title('London (\alpha_L Fit)')
subplot(2,3,3);title('London (Full Log Fit)')
subplot(2,3,4);title('England Exc. London (\alpha_L Fit)')
subplot(2,3,5);title('England Exc. London (\alpha_U Fit)')
subplot(2,3,6);title('England Exc. London (Full Log Fit)')

figure;
hold all;
p1 = plot(data_EN_ExcLDN.days, data_EN_ExcLDN.DeathsPDPM_EN_ExcLDN,'ro','MarkerSize',3,'MarkerFaceColor','r');
p2 = plot(data_EN_ExcLDN.days, data_EN_ExcLDN.DeathsPDPM_EN_LDN,'bo','MarkerSize',3,'MarkerFaceColor','b');

p3 = plot(t_fit1_EN_ExcLDN, exp(y_fit1_EN_ExcLDN),'r--');
p4 = plot(t_fit2_EN_ExcLDN, exp(y_fit2_EN_ExcLDN),'r-.');
plot(t_fit3_EN_ExcLDN, exp(y_fit3_EN_ExcLDN),'r-');

p5 = plot(t_fit1_EN_LDN, exp(y_fit1_EN_LDN),'b--');
p6 = plot(t_fit2_EN_LDN, exp(y_fit2_EN_LDN),'b-.');
plot(t_fit3_EN_LDN, exp(y_fit3_EN_LDN),'b-');

ylabel('Deaths per day per million');grid on;box on;
legend([p1 p2 p3 p4 p5 p6],'England exc. London data','London only data',...
                           ['\alpha_U = ',num2str(aU_EN_ExcLDN)],...
                           ['\alpha_L = ',num2str(aL_EN_ExcLDN)],...
                           ['\alpha_U = ',num2str(aU_EN_LDN)],...
                           ['\alpha_L = ',num2str(aL_EN_LDN)],...
                           'location','SouthEast')
set(gca,'YScale','log')
title('Deaths per day per million with fits for England and London')
xlim([60 150]);ylim([1e-2 1e2])
set(gcf,'color','w')

%% EXAMINING RESULTS

alpha_L_country = [aL_ES_ExcMD aL_IT_Exc25 aL_US_ExcNYC aL_EN_ExcLDN];
alpha_L_metro = [aL_ES_MD aL_IT_25 aL_US_NYC aL_EN_LDN];
alpha_U_country = [aU_ES_ExcMD aU_IT_Exc25 aU_US_ExcNYC aU_EN_ExcLDN];
alpha_U_metro = [aU_ES_MD aU_IT_25 aU_US_NYC aU_EN_LDN];

alpha_L = [aL_ES_MD aL_ES_ExcMD aL_IT_25 aL_IT_Exc25 aL_US_NYC aL_US_ExcNYC aL_EN_LDN aL_EN_ExcLDN];
alpha_U = [aU_ES_MD aU_ES_ExcMD aU_IT_25 aU_IT_Exc25 aU_US_NYC aU_US_ExcNYC aU_EN_LDN aU_EN_ExcLDN];

%% PLOTTING alpha L

confint_2_ES_MD = confint(fit_res2_ES_MD);
confint_2_ES_ExcMD = confint(fit_res2_ES_ExcMD);
confint_2_IT_25 = confint(fit_res2_IT_25);
confint_2_IT_Exc25 = confint(fit_res2_IT_Exc25);
confint_2_US_NYC = confint(fit_res2_US_NYC);
confint_2_US_ExcNYC = confint(fit_res2_US_ExcNYC);
confint_2_EN_LDN = confint(fit_res2_EN_LDN);
confint_2_EN_ExcLDN = confint(fit_res2_EN_ExcLDN);

error_alpha_L_metro = [(confint_2_ES_MD(2,1) - aL_ES_MD),...
                       (confint_2_IT_25(2,1) - aL_IT_25),...
                       (confint_2_US_NYC(2,1) - aL_US_NYC),...
                       (confint_2_EN_LDN(2,1) - aL_EN_LDN),...
                       ];

error_alpha_L_country = [(confint_2_ES_ExcMD(2,1) - aL_ES_ExcMD),...
                         (confint_2_IT_Exc25(2,1) - aL_IT_Exc25),...
                         (confint_2_US_ExcNYC(2,1) - aL_US_ExcNYC),...
                         (confint_2_EN_ExcLDN(2,1) - aL_EN_ExcLDN),...
                         ];

figure('color','w','Position',[488.2000  441.0000  560.8000  320.8000]);hold all;
errorbar(1:4,alpha_L_country,error_alpha_L_country,'o','color',[117,112,179]/255,'MarkerFaceColor',[190,174,212]/255,'Linewidth',2)
errorbar(1:4,alpha_L_metro,error_alpha_L_metro,'s','color',[217,95,2]/255,'MarkerFaceColor',[253,192,134]/255,'Linewidth',2)
legend('\alpha_L (country)','\alpha_L (metro)','location','NorthWest')
grid on;box on;
ylabel('\alpha_L')

str_metro = {'Madrid','Lombardy','New York City','London'};
str_country = {'Spain','Italy','U.S.','England'};

xlim([0 6])
set(gca,'XTick',1:4,'XTickLabel',{},'FontName','Gill Sans MT','FontSize',12)
xtickangle(90)

for k = 1:4
text(k+0.11,alpha_L_metro(k),str_metro(k), 'Interpreter', 'none','Color',[1 1 1]*0.4)
end

for k = 1:4
text(k+0.11,alpha_L_country(k),str_country(k), 'Interpreter', 'none','Color',[1 1 1]*0.4)
end

%% PLOTTING alpha U

confint_1_ES_MD = confint(fit_res1_ES_MD);
confint_1_ES_ExcMD = confint(fit_res1_ES_ExcMD);
confint_1_IT_25 = confint(fit_res1_IT_25);
confint_1_IT_Exc25 = confint(fit_res1_IT_Exc25);
confint_1_US_NYC = confint(fit_res1_US_NYC);
confint_1_US_ExcNYC = confint(fit_res1_US_ExcNYC);
confint_1_EN_LDN = confint(fit_res1_EN_LDN);
confint_1_EN_ExcLDN = confint(fit_res1_EN_ExcLDN);

error_alpha_U_metro = [(confint_1_ES_MD(2,1) - aU_ES_MD),...
                       (confint_1_IT_25(2,1) - aU_IT_25),...
                       (confint_1_US_NYC(2,1) - aU_US_NYC),...
                       (confint_1_EN_LDN(2,1) - aU_EN_LDN),...
                       ];

error_alpha_U_country = [(confint_1_ES_ExcMD(2,1) - aU_ES_ExcMD),...
                         (confint_1_IT_Exc25(2,1) - aU_IT_Exc25),...
                         (confint_1_US_ExcNYC(2,1) - aU_US_ExcNYC),...
                         (confint_1_EN_ExcLDN(2,1) - aU_EN_ExcLDN),...
                         ];

figure('color','w','Position',[488.2000  441.0000  560.8000  320.8000]);hold all;
errorbar(1:4,alpha_U_country,error_alpha_U_country,'o','color',[117,112,179]/255,'MarkerFaceColor',[190,174,212]/255,'Linewidth',2)
errorbar(1:4,alpha_U_metro,error_alpha_U_metro,'s','color',[217,95,2]/255,'MarkerFaceColor',[253,192,134]/255,'Linewidth',2)
legend('\alpha_U (country)','\alpha_U (metro)','location','NorthEast')
grid on;box on;
ylabel('\alpha_U')

str_metro = {'Madrid','Lombardy','New York City','London'};
str_country = {'Spain','Italy','U.S.','England'};

xlim([0 5])
set(gca,'XTick',1:4,'XTickLabel',{},'FontName','Gill Sans MT','FontSize',12)
xtickangle(90)

for k = 1:4
text(k+0.11,alpha_U_metro(k),str_metro(k), 'Interpreter', 'none','Color',[1 1 1]*0.4)
end

for k = 1:4
text(k+0.11,alpha_U_country(k),str_country(k), 'Interpreter', 'none','Color',[1 1 1]*0.4)
end
