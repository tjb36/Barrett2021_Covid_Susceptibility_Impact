function [fitresult, gof, t_fit, y_fit] = fit_full_log_aU_aL_CON(x, y, aU, aL, exc_indices)

[xData, yData] = prepareCurveData( x, y );

exc_indices(exc_indices > length(xData)) = [];

ft = [char(num2str(aU)), '*x + (',char(num2str(aL)),' - ' , char(num2str(aU)), ')*aW*log( exp(x/aW) + exp(t0/aW) ) + C']; % fix the upper value in the function
    
excludedPoints = excludedata( xData, yData, 'Indices', exc_indices);
opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
opts.Display = 'Off';
opts.StartPoint = [6 12 80];
opts.Exclude = excludedPoints;

% Fit model to data.
[fitresult, gof] = fit( xData, yData, ft, opts );

t_fit = linspace(0,200,1000);
coeff_values = coeffvalues(fitresult);
% 
y_fit = aU*t_fit + (aL - aU)*coeff_values(2)*...
        log( exp(t_fit/coeff_values(2)) + exp(coeff_values(3)/coeff_values(2)) ) + coeff_values(1);

% %Plot fit with data.
% figure( 'Name', 'untitled fit 1' );
h = plot( fitresult, xData, yData, excludedPoints,'r+' );
legend( h, 'Data', 'Excluded Points', ['Fit: t0 = ',num2str(coeff_values(3)),' , \alpha_W = ',num2str(coeff_values(2))], 'Location', 'SouthEast' );
% Label axes
xlabel x
ylabel y
grid on
ylim([-5 5])


end

