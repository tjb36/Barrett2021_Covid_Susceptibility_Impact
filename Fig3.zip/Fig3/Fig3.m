%%% Bring together the results of the sequential log fits to death data and
%%% the modified sigmoid fits to the Google Transit Station data, in order 
%%% to generate Figure 2 and 3.


% 1) Find day when full log fits to (deaths /day /million) reach 10% of the value
% that would be expected if the exponential growth continued (tc and tm).

% 2) Find day when sigmoid fit to Transit Station data passes the 50%
% threshold (ttc and ttm).

% 3) Calculate delay between 10% deaths day and 50% Transit Day (dc =
% tc-ttc). Use this to obtain the x-axis of the "wall/ceiling" graph.

% 4) Find the maximum value of the full log fit to (deaths/day/million),
% denoted by nc and nm. Multiply these values by correction factors to
% obtain the y-axis of the "wall/ceiling" graph.

clear;close all;clc;
load DATA
load FIT_RESULTS.mat

%% AESTHETIC PLOT PROPERTIES
fontname = 'Helvetica';
fontsize = 15;
xlims = [60 140];
ylims = [0.015 100];
ylims_TS = [-100 10];
subplotgap_hor = 0.01;
subplotgap_ver = 0.01;
marg_h = 0.1;
marg_w = 0.1;
axLineWidth = 2;
gridColor = 'g';
xticklocations = [60 75 90 105 120];
xticklabels = {'1^{st} Mar','','1^{st} Apr','','1^{st} May'};
purple = [153,112,171]/255;
green = [90,174,97]/255;
red = [203,24,29]/255;
blue = [33,113,181]/255;
lightred = [252,187,161]/255;
lightblue = [198,219,239]/255;
darkred = [165,15,21]/255;
darkblue = [8,81,156]/255;
ax_color = 'r';
deathsMetroFaceColour = blue;
deathsMetroLineColour = blue;
deathsMetroFitColour = blue;
deathsCountryFaceColour = red;
deathsCountryLineColour = red;
deathsCountryFitColour = darkred;
deathsFitLineWidth = 2;
deathsDataLineWidth = 0.1;
deathsDataMarkerSize = 3;
si_alpha = 0.3;
TSCountryDataColour = red;
TSMetroDataColour = blue;
TSDataAlpha = 0.2;
TSDataLineWidth = 2;
TSdelayedCountryDataColour = red;
TSdelayedMetroDataColour = blue;
TSdelayedAlpha = 1;
indicator50pctLineWidth = 1;
indicator50pctLineStyle = '-';
indicator50pctMetrocColor = blue;
indicator50pctCountryColor = red;

co = {'EN','US','ES','IT'};
me = {'LDN','NYC','MD','25'};
me2 = {'LDN','NY','MD','25'};

corr = [2.2 1.5 1.4 1.9]; % Correction factors due to underreporting from excess deaths
tdel = 20; % Expected offset between exposure and death (from clinical measurements)

t = 60:0.1:150;
perc = 0.1;   % Threshold for deaths data (when reach 10% of value if continued exponential rise)
ts_cut = -50; % Threshold for Transit Station data (when reaches 50%)
cf = 0.683;   % Confidence level for error bounds

%%% PLOT FULL LOG FITS, AND INDICATOR LINES
f1 = figure;
set(gcf,'color','w')
for j = 1:4
    str1_co = ['fit_res1_' co{j} '_Exc' me{j}];
    str2_co = ['fit_res2_' co{j} '_Exc' me{j}];
    str3_co = ['fit_res3_' co{j} '_Exc' me{j}];
    str1_me = ['fit_res1_' co{j} '_' me{j}];
    str2_me = ['fit_res2_' co{j} '_' me{j}];
    str3_me = ['fit_res3_' co{j} '_' me{j}];
    au = eval([str1_co '.a']);
    al = eval([str2_co '.a']);
    aw = eval([str3_co '.aW']);
    t0 = eval([str3_co '.t0']);
    c = eval([str3_co '.C']);
    pin_co = eval(['predint(' str3_co ',t,cf,''Observation'')']);
    pin_me = eval(['predint(' str3_me ',t,cf,''Observation'')']);
    pin_co_f = eval(['predint(' str3_co ',t,cf,''Functional'')']);
    pin_me_f = eval(['predint(' str3_me ',t,cf,''Functional'')']);
    ofs = (al-au)*t0+c;
    egr = au*t+ofs;
    egr2 = al*t;
    ful = au*t+(al-au)*aw*log(exp(t/aw)+exp(t0/aw))+c;
    [~,i] = min(abs(egr-ful+log(perc)));
    [~,in] = min(abs(egr-pin_co_f(:,1)'+log(perc)));
    [~,ipo] = min(abs(egr-pin_co_f(:,2)'+log(perc)));
    [~,ip] = max(ful);
    tc(j) = t(i);
    tcn(j) = t(in);
    tcp(j) = t(ipo);
    tpc(j) = t(ip);
    nc(j) = exp(ful(ip));
    ncn(j) = exp(ful(ip))-exp(pin_co_f(ip,1));
    ncp(j) = exp(pin_co_f(ip,2))-exp(ful(ip));
    
    %%% PLOT FIT FOR COUNTRY
    subtightplot(2,4,j,[subplotgap_ver,subplotgap_hor],marg_h,marg_w)
    semilogy(t,exp(ful),'-','LineWidth',deathsFitLineWidth,'color',deathsCountryFitColour) % Full log fit line
    hold on
    semilogy(t,exp(egr),'--','LineWidth',deathsFitLineWidth,'color',deathsCountryFitColour) % Initial slope line
    hold on
    semilogy(t,exp(egr2+c),'--','LineWidth',deathsFitLineWidth,'color',deathsCountryFitColour) % Initial slope line
    patch([t t(length(t):-1:1)],...
        [exp(pin_co(:,1))' exp(pin_co(length(t):-1:1,2))'],...
        [251 106 74]/255,'EdgeColor','none') % Confidence bounds on full log fit
    
    au = eval([str1_me '.a']);
    al = eval([str2_me '.a']);
    aw = eval([str3_me '.aW']);
    t0 = eval([str3_me '.t0']);
    c = eval([str3_me '.C']);
    ofs = (al-au)*t0+c;
    egr = au*t+ofs;
    ful = au*t+(al-au)*aw*log(exp(t/aw)+exp(t0/aw))+c;
    [~,i] = min(abs(egr-ful+log(perc)));
    [~,in] = min(abs(egr-pin_me_f(:,1)'+log(perc)));
    [~,ipo] = min(abs(egr-pin_me_f(:,2)'+log(perc)));
    [vp,ip] = max(ful);
    tm(j) = t(i);
    tmn(j) = t(in);
    tmp(j) = t(ipo);
    tpm(j) = t(ip);
    nm(j) = exp(ful(ip));
    nmn(j) = exp(ful(ip))-exp(pin_me_f(ip,1));
    nmp(j) = exp(pin_me_f(ip,2))-exp(ful(ip));
    
    %%% PLOT FIT FOR REGION
    semilogy(t,exp(ful),'-','LineWidth',deathsFitLineWidth,'color',deathsMetroFitColour) % Full log fit line
    semilogy(t,exp(egr),'--','LineWidth',deathsFitLineWidth,'color',deathsMetroFitColour) % Initial slope line
    hold off
    patch([t t(length(t):-1:1)],...
        [exp(pin_me(:,1))' exp(pin_me(length(t):-1:1,2))'],...
        [107 174 214]/255,'EdgeColor','none')  % Confidence bounds on full log fit
    alpha(0.3)
end

%% ADD DATA TO PLOTS

% ENGLAND/LONDON
tsi = data_EN_ExcLDN.days;
tsi([1 2 151 152]) = [];
si = data_EN_ExcLDN.stringency_index;
si([1 2 151 152]) = [];

subtightplot(2,4,1,[subplotgap_ver,subplotgap_hor],marg_h,marg_w)
hold all
p1 = semilogy(data_EN_ExcLDN.days,data_EN_ExcLDN.DeathsPDPM_EN_ExcLDN,'o');
set(p1,'color',deathsCountryLineColour,'LineWidth',deathsFitLineWidth,'MarkerFaceColor',deathsCountryFaceColour,'MarkerSize',deathsDataMarkerSize);
p2 = semilogy(data_EN_ExcLDN.days,data_EN_ExcLDN.DeathsPDPM_EN_LDN,   'o');
set(p2,'color',deathsMetroLineColour,  'LineWidth',deathsFitLineWidth,'MarkerFaceColor',deathsMetroFaceColour,  'MarkerSize',deathsDataMarkerSize);

line([1 1]*tc(1),[1e-4 1e10],'color',red,'LineWidth',1.5,'LineStyle',':')
line([1 1]*tm(1),[1e-4 1e10],'color',blue,'LineWidth',1.5,'LineStyle',':')

% Add patch for Stringency Index
y = ylim;
y = [y(1) y(1)+(y(1)+y(2))/100 y(2)];
for j = 1:(length(tsi)-1)
    patch([tsi(j) tsi(j) tsi(j+1) tsi(j+1)]+tdel,[y(1) y(3) y(3) y(1)],...
        [1-si(j+1)/100 1-si(j+1)/100 1-si(j+1)/100],...
        'EdgeColor','none')    
end
alpha(si_alpha)

% US/NYC
tsi = data_US.days;
tsi([1 151]) = [];
si = data_US.stringency_index;
si([1 151]) = [];

subtightplot(2,4,2,[subplotgap_ver,subplotgap_hor],marg_h,marg_w)
hold all
p3 = semilogy(data_US_ExcNY.days,data_US_ExcNY.DeathsPDPM_US_ExcNYC,'o');
set(p3,'color',deathsCountryLineColour,'LineWidth',deathsFitLineWidth,'MarkerFaceColor',deathsCountryFaceColour,'MarkerSize',deathsDataMarkerSize);
p4 = semilogy(data_US_NYC.days,data_US_NYC.DeathsPDPM_US_NYC,'o');
set(p4,'color',deathsMetroLineColour,  'LineWidth',deathsFitLineWidth,'MarkerFaceColor',deathsMetroFaceColour,  'MarkerSize',deathsDataMarkerSize);

line([1 1]*tc(2),[1e-4 1e10],'color',red,'LineWidth',1.5,'LineStyle',':')
line([1 1]*tm(2),[1e-4 1e10],'color',blue,'LineWidth',1.5,'LineStyle',':')

% Add patch for Stringency Index
y = ylim;
y = [y(1) y(1)+(y(1)+y(2))/100 y(2)];
for j = 1:(length(tsi)-1)
    patch([tsi(j) tsi(j) tsi(j+1) tsi(j+1)]+tdel,[y(1) y(3) y(3) y(1)],...
        [1-si(j+1)/100 1-si(j+1)/100 1-si(j+1)/100],...
        'EdgeColor','none')
end
alpha(si_alpha)

% SPAIN/MADRID
tsi = data_ES.days;
tsi([1 144:150]) = [];
si = data_ES.stringency_index;
si([1 144:150]) = [];

subtightplot(2,4,3,[subplotgap_ver,subplotgap_hor],marg_h,marg_w)
hold all
p5 = semilogy(data_ES_ExcMD.days,data_ES_ExcMD.DeathsPDPM_ES_ExcMD,'o');
set(p5,'color',deathsCountryLineColour,'LineWidth',deathsFitLineWidth,'MarkerFaceColor',deathsCountryFaceColour,'MarkerSize',deathsDataMarkerSize);
p6 = semilogy(data_ES_MD.days,data_ES_MD.DeathsPDPM,'o');
set(p6,'color',deathsMetroLineColour,  'LineWidth',deathsFitLineWidth,'MarkerFaceColor',deathsMetroFaceColour,  'MarkerSize',deathsDataMarkerSize);

line([1 1]*tc(3),[1e-4 1e10],'color',red,'LineWidth',1.5,'LineStyle',':')
line([1 1]*tm(3),[1e-4 1e10],'color',blue,'LineWidth',1.5,'LineStyle',':')

% Add patch for Stringency Index
y = ylim;
y = [y(1) y(1)+(y(1)+y(2))/100 y(2)];
for j = 1:(length(tsi)-1)
    patch([tsi(j) tsi(j) tsi(j+1) tsi(j+1)]+tdel,[y(1) y(3) y(3) y(1)],...
        [1-si(j+1)/100 1-si(j+1)/100 1-si(j+1)/100],...
        'EdgeColor','none')
end
alpha(si_alpha)

% ITALY/LOMBARDY
tsi = data_IT.days;
tsi([1 147:151]) = [];
si = data_IT.stringency_index;
si([1 147:151]) = [];

subtightplot(2,4,4,[subplotgap_ver,subplotgap_hor],marg_h,marg_w)
hold all
p7 = semilogy(data_IT_Exc25.days,data_IT_Exc25.DeathsPDPM_IT_Exc25,'o');
set(p7,'color',deathsCountryLineColour,'LineWidth',deathsFitLineWidth,'MarkerFaceColor',deathsCountryFaceColour,'MarkerSize',deathsDataMarkerSize);
p8 = semilogy(data_IT_25.days,data_IT_25.DeathsPDPM,'o');
set(p8,'color',deathsMetroLineColour,  'LineWidth',deathsFitLineWidth,'MarkerFaceColor',deathsMetroFaceColour,  'MarkerSize',deathsDataMarkerSize);

line([1 1]*tc(4),[1e-4 1e10],'color',red,'LineWidth',1.5,'LineStyle',':')
line([1 1]*tm(4),[1e-4 1e10],'color',blue,'LineWidth',1.5,'LineStyle',':')

% Add patch for Stringency Index
y = ylim;
y = [y(1) y(1)+(y(1)+y(2))/100 y(2)];
for j = 1:(length(tsi)-1)
    patch([tsi(j) tsi(j) tsi(j+1) tsi(j+1)]+tdel,[y(1) y(3) y(3) y(1)],...
        [1-si(j+1)/100 1-si(j+1)/100 1-si(j+1)/100],...
        'EdgeColor','none')
end
alpha(si_alpha)



%% MOBILITY DATA PLOTS %%%
t = 50:0.1:110;
for j = 1:4
    
    % m = metro, c = country
    
    str4_co = ['fit_res_TS_' co{j}];
    str4_me = ['fit_res_TS_' me2{j}];
    
    % Prediction intervals for Transit Sigmoid fits
    pit_co = eval(['predint(' str4_co ',t,cf,''Observation'')']); % Country, Observation
    pit_me = eval(['predint(' str4_me ',t,cf,''Observation'')']); % Metro, Observation
    pit_co_f = eval(['predint(' str4_co ',t,cf,''Functional'')']); % Country, Functional
    pit_me_f = eval(['predint(' str4_me ',t,cf,''Functional'')']); % Metro, Functional
    
    ts = eval([str4_co '(t)']); % Evaluate the country fit result at times t
    
    [~,i] = min(abs(ts-ts_cut)); % Find index when Transit goes below 50%
    [~,in] = min(abs(pit_co_f(:,1)-ts_cut)); % Find index when fit bounds go past 50%
    [~,ip] = min(abs(pit_co_f(:,2)-ts_cut));
    ttc(j) = t(i); % Find times when fit and fit bounds go past 50%
    ttcn(j) = t(in); 
    ttcp(j) = t(ip);
    subtightplot(2,4,j+4,[subplotgap_ver,subplotgap_hor],marg_h,marg_w)
    hold all
    
    %%% Repeat for Metro Region %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    ts = eval([str4_me '(t)']);
    [~,i] = min(abs(ts-ts_cut));
    [~,in] = min(abs(pit_me_f(:,1)-ts_cut));
    [~,ip] = min(abs(pit_me_f(:,2)-ts_cut));
    ttm(j) = t(i);
    ttmn(j) = t(in);
    ttmp(j) = t(ip);
   
    alpha(0.3)
    
end

% Add Data to Mobility Plots %
subtightplot(2,4,5,[subplotgap_ver,subplotgap_hor],marg_h,marg_w)
hold all
p9 = plot(data_EN_ExcLDN.days,data_EN_ExcLDN.TS_EN);
set(p9,'color',[TSCountryDataColour TSDataAlpha],'LineWidth',TSDataLineWidth)
p17 = plot(data_EN_ExcLDN.days+tdel,data_EN_ExcLDN.TS_EN);
set(p17,'color',[TSdelayedCountryDataColour TSdelayedAlpha],'LineWidth',TSDataLineWidth)
p10 = plot(data_EN_ExcLDN.days,data_EN_ExcLDN.TS_LDN);
set(p10,'color',[TSMetroDataColour TSDataAlpha],'LineWidth',TSDataLineWidth)
p18 = plot(data_EN_ExcLDN.days+tdel,data_EN_ExcLDN.TS_LDN);
set(p18,'color',[TSdelayedMetroDataColour TSdelayedAlpha],'LineWidth',TSDataLineWidth)

subtightplot(2,4,6,[subplotgap_ver,subplotgap_hor],marg_h,marg_w)
hold all
p11 = plot(data_US_ExcNY.days,data_US_ExcNY.TS_US);
set(p11,'color',[TSCountryDataColour TSDataAlpha],'LineWidth',TSDataLineWidth)
p19 = plot(data_US_ExcNY.days+tdel,data_US_ExcNY.TS_US);
set(p19,'color',[TSdelayedCountryDataColour TSdelayedAlpha],'LineWidth',TSDataLineWidth)
p12 = plot(data_US_NYC.days,data_US_NYC.TS_NY);
set(p12,'color',[TSMetroDataColour TSDataAlpha],'LineWidth',TSDataLineWidth)
p20 = plot(data_US_NYC.days+tdel,data_US_NYC.TS_NY);
set(p20,'color',[TSdelayedMetroDataColour TSdelayedAlpha],'LineWidth',TSDataLineWidth)

subtightplot(2,4,7,[subplotgap_ver,subplotgap_hor],marg_h,marg_w)
hold all
p13 = plot(data_ES_ExcMD.days,data_ES_ExcMD.TS_ES);
set(p13,'color',[TSCountryDataColour TSDataAlpha],'LineWidth',TSDataLineWidth)
p21 = plot(data_ES_ExcMD.days+tdel,data_ES_ExcMD.TS_ES);
set(p21,'color',[TSdelayedCountryDataColour TSdelayedAlpha],'LineWidth',TSDataLineWidth)
p14 = plot(data_ES_ExcMD.days,data_ES_ExcMD.TS_MD);
set(p14,'color',[TSMetroDataColour TSDataAlpha],'LineWidth',TSDataLineWidth)
p22 = plot(data_ES_ExcMD.days+tdel,data_ES_ExcMD.TS_MD);
set(p22,'color',[TSdelayedMetroDataColour TSdelayedAlpha],'LineWidth',TSDataLineWidth)

subtightplot(2,4,8,[subplotgap_ver,subplotgap_hor],marg_h,marg_w)
hold all
p15 = plot(data_IT_Exc25.days,data_IT_Exc25.TS_IT);
set(p15,'color',[TSCountryDataColour TSDataAlpha],'LineWidth',TSDataLineWidth)
p23 = plot(data_IT_Exc25.days+tdel,data_IT_Exc25.TS_IT);
set(p23,'color',[TSdelayedCountryDataColour TSdelayedAlpha],'LineWidth',TSDataLineWidth)
p16 = plot(data_IT_Exc25.days,data_IT_Exc25.TS_25);
set(p16,'color',[TSMetroDataColour TSDataAlpha],'LineWidth',TSDataLineWidth)
p24 = plot(data_IT_Exc25.days+tdel,data_IT_Exc25.TS_25);
set(p24,'color',[TSdelayedMetroDataColour TSdelayedAlpha],'LineWidth',TSDataLineWidth)

% TWEAK AESTHETIC THINGS IN PLOTS %%%
set(gcf,'Position',[1.9594   -0.0550    1.8464    0.6520]*1e3)

% Get axis handles
subtightplot(2,4,1,[subplotgap_ver,subplotgap_hor],marg_h,marg_w)
ax1 = gca;
subtightplot(2,4,2,[subplotgap_ver,subplotgap_hor],marg_h,marg_w)
ax2 = gca;
subtightplot(2,4,3,[subplotgap_ver,subplotgap_hor],marg_h,marg_w)
ax3 = gca;
subtightplot(2,4,4,[subplotgap_ver,subplotgap_hor],marg_h,marg_w)
ax4 = gca;
subtightplot(2,4,5,[subplotgap_ver,subplotgap_hor],marg_h,marg_w)
ax5 = gca;
subtightplot(2,4,6,[subplotgap_ver,subplotgap_hor],marg_h,marg_w)
ax6 = gca;
subtightplot(2,4,7,[subplotgap_ver,subplotgap_hor],marg_h,marg_w)
ax7 = gca;
subtightplot(2,4,8,[subplotgap_ver,subplotgap_hor],marg_h,marg_w)
ax8 = gca;

%%%% TWEAK PLOT SETTINGS FOR DEATH DATA (upper 4 plots)
set([ax1 ax2 ax3 ax4],'XLim',xlims,...
                      'YLim',ylims,...
                      'XTick',[60 90 120],...
                      'XTickLabel','',...
                      'YTickLabel','',...
                      'YTick',[0.1 1 10 100],...
                      'XGrid','on',...
                      'YGrid','on',...
                      'XMinorGrid','off',...
                      'YMinorGrid','on',...
                      'YMinorTick','on',...
                      'XMinorTick','off',...
                      'YColor','k',...
                      'XColor','k',...
                      'LineWidth',1.5,...
                      'TickLength',[0.02 0],...
                      'Color','w',...
                      'GridAlpha',0.05,...
                      'GridAlphaMode','manual',...
                      'GridColor','k',...
                      'GridColorMode','manual',...
                      'MinorGridAlpha',0.05,...
                      'MinorGridAlphaMode','manual',...
                      'MinorGridColor','k',...
                      'MinorGridColorMode','manual',...
                      'MinorGridLineStyle','-',...
                      'FontName',fontname,...
                      'FontSize',fontsize,...
                      'Box','on')
set(ax1,'YTickLabel',{'0.1' '1' '10' '100'})
ylabel(ax1,{'Deaths per Day','per Million'})
legend(ax1,[p1 p2],{'England','London'},'location','SouthEast');
legend(ax2,[p3 p4],{'United States','New York City'},'location','SouthEast');
legend(ax3,[p5 p6],{'Spain','Madrid'},'location','SouthEast');
legend(ax4,[p7 p8],{'Italy','Lombardy'},'location','SouthEast');
set([p1 p3 p4 p7],'Marker','o')
set([p2 p4 p6 p8],'Marker','s')

%%%% TWEAK PLOT SETTINGS FOR MOBILITY DATA (lower 4 plots)
TS_plotfac = 0.5;
TS_plotshift = 0.2;
set(ax5,'Position',get(ax5,'Position').*[1 1 1 TS_plotfac]+[0 TS_plotshift 0 0])
set(ax6,'Position',get(ax6,'Position').*[1 1 1 TS_plotfac]+[0 TS_plotshift 0 0])
set(ax7,'Position',get(ax7,'Position').*[1 1 1 TS_plotfac]+[0 TS_plotshift 0 0])
set(ax8,'Position',get(ax8,'Position').*[1 1 1 TS_plotfac]+[0 TS_plotshift 0 0])
set([ax5 ax6 ax7 ax8],'XLim',xlims,...
                      'YLim',ylims_TS,...
                      'XTick',[60 90 120],...
                      'XTickLabel',{''},...
                      'YTickLabel','',...
                      'YTick',[-100 -50 0],...
                      'XGrid','on',...
                      'YGrid','on',...
                      'XMinorGrid','off',...
                      'YMinorGrid','off',...
                      'YMinorTick','on',...
                      'XMinorTick','off',...
                      'YColor','k',...
                      'XColor','k',...
                      'LineWidth',1.5,...
                      'TickLength',[0.02 0],...
                      'Color','w',...
                      'GridAlpha',0.05,...
                      'GridAlphaMode','manual',...
                      'GridColor','k',...
                      'GridColorMode','manual',...
                      'MinorGridAlpha',0.05,...
                      'MinorGridAlphaMode','manual',...
                      'MinorGridColor','k',...
                      'MinorGridColorMode','manual',...
                      'MinorGridLineStyle','-',...
                      'FontName',fontname,...
                      'FontSize',fontsize,...
                      'Box','on')
set(ax5,'YTickLabel',{'-100' '-50' '0'})
ylabel(ax5,{'Transit Usage [%]'})

% To save a version with larger markers (use in legend)
% set([p1 p2 p3 p4 p5 p6 p7 p8],'MarkerSize',5)
% export_fig Fig2_A -png -opengl -p0.01 -r600 % Works

set([p1 p2 p3 p4 p5 p6 p7 p8],'MarkerSize',deathsDataMarkerSize)
%export_fig Fig2_B -png -opengl -p0.01 -r600


%% WALL/CEILING %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fontsize = 11;
clist = 1:4;
dc = tc-ttc;
dm = tm-ttm;
dcn = sqrt((tc-tcn).^2+(ttc-ttcn).^2);
dcp = sqrt((tc-tcp).^2+(ttc-ttcp).^2);
dmn = sqrt((tm-tmn).^2+(ttm-ttmn).^2);
dmp = sqrt((tm-tmp).^2+(ttm-ttmp).^2);

%%% create data to describe distribution of shaded areas
x_area = linspace(7.08,20.5,1000);
y_area = linspace(1,150,1000);
[X_area,Y_area] = meshgrid(x_area,y_area);
Z1 = exp(-(Y_area-140).^2/(2*15^2)); % blue
Z2 = exp(-(X_area-20).^2/(2*2^2)); % red

%%% Set up colormap (concatenate two colormaps)
% https://www.mathworks.com/matlabcentral/answers/101346-how-do-i-use-multiple-colormaps-in-a-single-figure#answer_110694
n_levels = 256;
start_color_1 = blue; 
start_color_2 = red; 
cmap1 = [linspace(1,start_color_1(1),n_levels)' linspace(1,start_color_1(2),n_levels)' linspace(1,start_color_1(3),n_levels)'];
cmap2 = [linspace(1,start_color_2(1),n_levels)' linspace(1,start_color_2(2),n_levels)' linspace(1,start_color_2(3),n_levels)'];
cmap = [cmap1;cmap2];

f3 = figure;
h = axes;

hold all
h1 = imagesc(x_area,y_area,Z1);
h2 = imagesc(x_area,y_area,Z2);
h1.AlphaData = 0.2;
h2.AlphaData = 0.2;
colormap(cmap)

% CData for area 1 (should be blue)
C1 = min(n_levels,round((n_levels-1)*Z1)+1); 
% CData for area 2 (should be red)
C2 = min(n_levels,round((n_levels-1)*Z2)+1) + n_levels;
% Update the CDatas for each area.
set(h1,'CData',C1);
set(h2,'CData',C2);
% Change the CLim property of axes so that it spans the 
% CDatas of both objects.
caxis([1 2*n_levels])

plot(dc,nc,'o','color',red);
hold on
errorbar(dc,corr.*nc,corr.*ncn,corr.*ncp,dcn,dcp,'o','color',darkred,...
    'MarkerFaceColor',red,'MarkerSize',6,'LineWidth',1.5)
plot(dm,nm,'o','color',blue)
errorbar(dm,corr.*nm,corr.*nmn,corr.*nmp,dmn,dmp,'o','color',darkblue,...
    'MarkerFaceColor',blue,'MarkerSize',6,'LineWidth',1.5)
hold off
h.YScale='log';

for j = 1:4
    line([tc(j)-ttc(j) tc(j)-ttc(j)],[nc(j) nc(j)*corr(j)],...
        'Color',red,'LineStyle',':','LineWidth',1.5)
    line([tm(j)-ttm(j) tm(j)-ttm(j)],[nm(j) nm(j)*corr(j)],...
        'Color',blue,'LineStyle',':','LineWidth',1.5)
end



grid on;box on;
set(gca,'YScale','log','MinorGridLineStyle','-','MinorGridColor',[1 1 1]*1);
set(gca,'LineWidth',axLineWidth)
set(gcf,'color','w')
set(gca,'YTick',[1 10 100],'YTickLabel',{'1','10','100'})
ylabel({'Peak deaths per day';'per million population'})
xlabel('Time Delay [days]')
set(gca,'FontName',fontname,'FontSize',fontsize+2)
xlim([7 20.5])
ylim([1 150])

load('ExDe_Eng.mat')
Eng_Comp.days = datenum(Eng_Comp.date) - datenum('01-Jan-2020');
FT_Eng_2020.days = datenum(FT_Eng_2020.date) - datenum('01-Jan-2020');
Eng_Comp_TT = table2timetable(Eng_Comp);
Eng_Comp_TT_wkly = retime(Eng_Comp_TT,'weekly','sum');
Eng_Comp_TT_wkly.days = datenum(Eng_Comp_TT_wkly.date) - datenum('01-Jan-2020');

ax_inset = axes;
set(gca,'Position',[0.2786    0.2052    0.3014    0.3357])
hold all;

p26 = plot(Eng_Comp_TT_wkly.days,Eng_Comp_TT_wkly.NHSpd);
p27 = plot(Eng_Comp_TT_wkly.days,Eng_Comp_TT_wkly.NHSpd*2.1);
p25 = plot(FT_Eng_2020.days-10,FT_Eng_2020.excess);

set(p25,'color','k','LineWidth',1.3,'Marker','s','MarkerSize',6,'LineStyle','--')
set(p26,'color',[TSCountryDataColour TSDataAlpha],'LineWidth',1.3,'Marker','o','MarkerSize',6)
set(p27,'color',[TSdelayedCountryDataColour TSdelayedAlpha],'LineWidth',1,'Marker','o','MarkerFaceColor',TSdelayedCountryDataColour,'MarkerSize',4)

xlim([60 150]);ylim([-500 15000])
box on;
ylabel({'Weekly Deaths';'[thousands]'})
set(gca,'YTick',[0 5000 10000 15000],'YTickLabel',{'0','5','10','15'});
set(gca,'XTick',[60    90   120],'XTickLabels',{})
set(gca,'FontName',fontname,'FontSize',12)
set(gca,'LineWidth',axLineWidth,'TickLength',[0.03 0])

