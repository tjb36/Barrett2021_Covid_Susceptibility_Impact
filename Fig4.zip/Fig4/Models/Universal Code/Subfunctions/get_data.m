function [data_1,data_2,t1,t2]=get_data(str)

% Get data_1 and data_2 for code
% Possible calls are england,italy,spain,usa
load('Timetables.mat')
str=lower(str);
if strcmp(str,'spain')
    
    data_ES=data_ES_ExcMD.LOG_DeathsPDPM_ES_ExcMD+log(1.4);
    data_MD=data_ES_ExcMD.LOG_DeathsPDPM_ES_MD+log(1.4);
    
    t=data_ES_ExcMD.days;
    
    data_1=data_ES;
    data_2=data_MD;
    
elseif strcmp(str,'england')
    data_LDN=data_EN_ExcLDN.LOG_DeathsPDPM_EN_LDN+log(2.2);
    data_EN=data_EN_ExcLDN.LOG_DeathsPDPM_EN_ExcLDN+log(2.2);
    
    t=data_EN_ExcLDN.days;
    
    data_1=data_EN;
    data_2=data_LDN;
    
elseif strcmp(str,'italy')
    
    
    data_IT=data_IT_Exc25.LOG_DeathsPDPM_IT_Exc25+log(1.9);
    data_IT_25=data_IT_Exc25.LOG_DeathsPDPM_IT_25+log(1.9);
    
    t=data_IT_Exc25.days;
    
    data_1=data_IT;
    data_2=data_IT_25;
    
    
elseif strcmp(str,'usa')
    data_US=data_US_ExcNY.LOG_DeathsPDPM_US_ExcNYC+log(1.5); % Edit here
    data_NYC=data_US_ExcNY.LOG_DeathsPDPM_US_NYC+log(1.5); % Edit here
    
    t=data_US_ExcNY.days; % Edit here
    
    data_1=data_US; % Edit here
    data_2=data_NYC; % Edit here
    
else
    error('Invalid input')
end


ind1=find(~isnan(data_1));
t1=t(ind1);
data_1=data_1(ind1);
ind1_inf=find(abs(data_1)~=inf);
t1=t1(ind1_inf);
data_1=data_1(ind1_inf);

ind2=find(~isnan(data_2));
t2=t(ind2);
data_2=data_2(ind2);
ind2_inf=find(abs(data_2)~=inf);
t2=t2(ind2_inf);
data_2=data_2(ind2_inf);