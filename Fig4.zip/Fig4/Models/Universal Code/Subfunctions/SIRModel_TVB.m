function dy=SIRModel_TVB(t,y,b1,gam,N,bi,bf,bw,t0)

S=y(1);
I=y(2);
% R=y(4);
% D=y(5);

sig=@(bi,bf,bw,t0,t) (bf-bi)./(1+exp(-(t-t0)/bw))+bi;
b1=sig(bi,bf,bw,t0,t);

dS=-b1.*I.*S/N;
dI=b1.*I.*S/N-I*gam;
dR=I*gam;
dailyInf=dI*gam;
dy=[dS;dI;dR;dailyInf];