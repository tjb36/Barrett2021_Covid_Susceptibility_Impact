function cost=TwoCostFun_US(t1,t2,data1,data2,p,gam,N,dt,bi1,bi2,betaratio,muratio,plt)


data1=data1(:);
data2=data2(:);

ts=p(1);
te=p(2); % lockdown start
toff=p(3);
% bi=p(4);
bf=p(4);
bw=p(5);
Pdead=p(6);

bfm=betaratio*bf;
Pdeadm=Pdead.*muratio;


b1=1;

y0=[N-1,1,0,0];
t=linspace(ts,t1(1),1001);
% Burn in 
options=odeset('event',@(t,y) StopEvent3(t,y,Pdead,data1));
[T1,Y1,~,~]=ode45(@(t,y) SIRModel_TVB(t,y,b1,gam,N,bi1,bf,bw,te),t,y0,options);
y0=Y1(end,:);
t=t1;
[T,Y]=ode45(@(t,y) SIRModel_TVB(t,y,b1,gam,N,bi1,bf,bw,te),t,y0);


diff1=data1-log(Y(:,4)*Pdead);
cost1=sqrt(mean(diff1.^2));

% #########################################
if plt==1
figure(101)
h1=plot(t1,exp(data1),'b.','linewidth',2);
hold on
p1=plot(t2,exp(data2),'r.','linewidth',2);
h2=plot(T1,exp(log(Y1(:,4)*Pdead)),'b--','linewidth',2);
h3=plot(T,exp(log(Y(:,4)*Pdead)),'b','linewidth',2);
h2.Color(4) = 0.25;
h3.Color(4) = 0.25;
end
% #########################################


b1=1;
y0=[N-1,1,0,0];
t=linspace(ts-toff,t2(1),1001);
% Burn in 
options=odeset('event',@(t,y) StopEvent3(t,y,Pdeadm,data2));
[T1,Y1,~,~]=ode45(@(t,y) SIRModel_TVB(t,y,b1,gam,N,bi2,bfm,bw,te-dt),t,y0,options);
y0=Y1(end,:);
t=t2;
[T,Y]=ode45(@(t,y) SIRModel_TVB(t,y,b1,gam,N,bi2,bfm,bw,te-dt),t,y0);



% #########################################
if plt==1
p2=plot(T1,exp(log(Y1(:,4)*Pdeadm)),'r--','linewidth',2);
p3=plot(T,exp(log(Y(:,4)*Pdeadm)),'r','linewidth',2);
p2.Color(4) = 0.25;
p3.Color(4) = 0.25;
set(gca,'yscale','log')
drawnow
hold off
end
% #########################################

diff2=data2-log(Y(:,4)*Pdeadm);
cost2=sqrt(mean(diff2.^2));

cost=(cost1+cost2);
% +cost2
if imag(cost)~=0
   cost = 1e10; 
end
% cost1+
% Ends here
