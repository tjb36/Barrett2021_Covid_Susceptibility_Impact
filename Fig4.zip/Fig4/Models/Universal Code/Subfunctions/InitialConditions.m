function [p0,bi,dt]=InitialConditions(str,gam)
% get initial conditions for the fit
% ts = seed time for country
% toff = difference between seed time in country and metro
% te = t0 of the intervention
% bf = downwards slope
% Pdead = Infection fatality rate
% bi = initial slope
% dt = time between metro te and country te

str=lower(str);
load('FIT_RESULTS.mat')


if strcmp(str,'england')

bi=fit_res1_EN_ExcLDN.a+gam;
bi=[bi,bi];
t0_EN=fit_res_TS_EN.t0;
t0_LDN=fit_res_TS_LDN.t0;
dt=t0_EN-t0_LDN;
W_EN=fit_res_TS_EN.W;
toff=10;
% W_LDN=fit_res_TS_LDN.W;
bw=W_EN;

ts=60;
te=t0_EN+20;
bf=fit_res2_EN_ExcLDN.a+gam;
Pdead=1/300;

p0=[ts,te,toff,bf,bw,Pdead];

elseif strcmp(str,'spain')

bi=fit_res1_ES_ExcMD.a+gam;
bi=[bi,bi];
t0_ES=fit_res_TS_ES_ExcMD.t0;
W_ES=fit_res_TS_ES_ExcMD.W;
bw=W_ES;
dt=3;
bf=fit_res2_ES_MD.a+gam;
ts=60;
te=t0_ES+15;
toff=4;
Pdead=1/151;
p0=[ts,te,toff,bf,bw,Pdead];

elseif strcmp(str,'italy')

bi=fit_res1_IT_25.a+gam;
bi=[bi,bi];
t0_IT=fit_res_TS_IT.t0;
t0_25=fit_res_TS_25.t0;
dt=t0_IT-t0_25;
W_IT=fit_res_TS_IT.W;
bw=W_IT;
ts=50;
te=t0_IT+15;
toff=8;
bf=fit_res2_IT_Exc25.a+gam;
Pdead=1/151;
p0=[ts,te,toff,bf,bw,Pdead];

elseif strcmp(str,'usa')

bi1=fit_res1_US_ExcNYC.a+gam;
bi2=fit_res1_US_NYC.a+gam;
bi=[bi1,bi2];
dt=8;
W_US=fit_res_TS_US.W; 
bw=W_US;
ts=55;
te=92;
toff=0.4;
bf=fit_res2_US_ExcNYC.a+gam;
Pdead=1/151;

p0=[ts,te,toff,bf,bw,Pdead];
else
error('Invalid input')

end