clearvars;close all;clc;
% str='england';
str='spain';
% str='italy';
% str='usa';

Tserial=4;
tau=3.4;
R0=exp(Tserial/tau);
gam=1./(tau.*(R0-1));

[data1,data2,t1,t2]=get_data(str);
[p0,bi,dt]=InitialConditions(str,gam);

% Plotting options 1= plot, 0 = dont plot
plt=1; % Plotting in fit function

% Relaxation for extra UK data
Relaxation=1; %Relaxation of lockdown
bf_R=0.17; % New betaf for relaxed lockdown
bw_R=10; % Width of relaxation
back=5; % how many points back into the data the beta f changes
t0_R=t1(end-back); % t0 of relaxation
ts_R=t1(end-back);

NoS=1; % Plot with no effect from S
TEnd_NoS=182; % End time for NoS plot
NoLockdown=1; % Plot for no lockdown
TEnd_NoLD=182;
T_extrapolation=300; % Plot fits until this time

% Extrapolation of
FullRelease=1;

if ~strcmp(str,'england')
   Rekaxation=0; 
end

betaratio=1; % ratio between bf_metro and bf_city bfm=bf*beatratio
muratio=1/1.6; % ratio between mu_metro and mu_city mu_m=mu*muratio

N=1e6;
Nparam=length(p0);


bi1=bi(1);
bi2=bi(2);
fun=@(p) UniversalCostFunction(t1,t2,data1,data2,p,...
    gam,N,dt,bi1,bi2,betaratio,muratio,plt);


search_options=optimset('MaxFunEvals',800*Nparam,'MaxIter',800*Nparam,...
    'TolFun',1e-5,'TolX',1e-5);
p=fminsearch(fun,p0,search_options);

ts=p(1);
te=p(2);
toff=p(3);
bf=p(4);
bw=p(5);
Pdead=p(6);
Pdeadm=Pdead.*muratio;
bfm=betaratio*bf;

fprintf('mu_c \t %0.2f%% \nmu_m \t %0.2f%% \nbeta_c \t %0.2f \nbeta_m \t %0.2f \n',...
    Pdead*100,Pdeadm*100,bf,bfm);

% Plotting fit results
b1=1;

y0=[N-1,1,0,0];
t=linspace(ts,t1(1),1001);
% Burn in
options=odeset('event',@(t,y) StopEvent3(t,y,Pdead,data1));
[T1c,Y1c,~,~]=ode45(@(t,y) SIRModel_TVB(t,y,b1,gam,N,bi1,bf,bw,te),t,y0,options);
y0=Y1c(end,:);
t=t1;
% t=linspace(t1(1),T_extrapolation,101);
[Tc,Yc]=ode45(@(t,y) SIRModel_TVB(t,y,b1,gam,N,bi1,bf,bw,te),t,y0);
InitialDailyDead_c=log(Y1c(:,4)*Pdead);
DailyDead_c=log(Yc(:,4)*Pdead);
S_c=Yc(:,1)/N;

y0=[N-1,1,0,0];
t=linspace(ts-toff,t2(1),1001);
% Burn in
options=odeset('event',@(t,y) StopEvent3(t,y,Pdeadm,data2));
[T1m,Y1m,~,~]=ode45(@(t,y) SIRModel_TVB(t,y,b1,gam,N,bi2,bfm,bw,te-dt),t,y0,options);
y0=Y1m(end,:);
t=t2;
% t=linspace(t2(1),T_extrapolation,101);
[Tm,Ym]=ode45(@(t,y) SIRModel_TVB(t,y,b1,gam,N,bi2,bfm,bw,te-dt),t,y0);
InitialDailyDead_m=log(Y1m(:,4)*Pdeadm);
DailyDead_m=log(Ym(:,4)*Pdeadm);
S_m=Ym(:,1)/N;

% Fits to the end
y0=Yc(end,:);
% t=t1;
t=linspace(t1(end),T_extrapolation,101);
[Tc_ext,Yc_ext]=ode45(@(t,y) SIRModel_TVB(t,y,b1,gam,N,bi1,bf,bw,te),t,y0);
DailyDead_cext=log(Yc_ext(:,4)*Pdead);
S_cext=Yc_ext(:,1)/N;


y0=Ym(end,:);
% t=t2;
t=linspace(t2(end),T_extrapolation,101);
[Tm_ext,Ym_ext]=ode45(@(t,y) SIRModel_TVB(t,y,b1,gam,N,bi2,bfm,bw,te-dt),t,y0);
DailyDead_mext=log(Ym_ext(:,4)*Pdeadm);
S_mext=Ym_ext(:,1)/N;

ratio=S_mext(end)./S_cext(end);

% Colors
blue_3=[33,113,181]/255;
blue_4=[8,81,156]/255;

red_3=[203,24,29]/255;
red_4=[165,15,21]/255;

green_1=[247,252,253]/255;
green_2=[186,228,179]/255;
green_3=[116,196,118]/255;
green_4=[35,139,69]/255;

figure(1)
hold on
Containment=10*Pdead;
v=[50,10^-2;T_extrapolation,10^-2;T_extrapolation,Containment;50,Containment];
% v=[50,0.01;250,0.01;250,1;50,1];
f=[1,2,3,4];
C=[green_4;green_4;green_1;green_1];
pat=patch('Faces',f,'Vertices',v,'FaceVertexCData',C,'FaceColor','interp','edgecolor','none');
pat.Annotation.LegendInformation.IconDisplayStyle = 'off';

c1=plot(t1,exp(data1),'o','linewidth',2,'markerfacecolor',red_3,'color',red_4,'markersize',4);
m1=plot(t2,exp(data2),'o','linewidth',2,'markerfacecolor',blue_3,'color',blue_4,'markersize',4);
c2=plot(T1c,exp(InitialDailyDead_c),'r','linewidth',2);
m2=plot(T1m,exp(InitialDailyDead_m),'b','linewidth',2);
c3=plot(Tc,exp(DailyDead_c),'r','linewidth',2);
m3=plot(Tm,exp(DailyDead_m),'b','linewidth',2);
c4=plot(Tc_ext,exp(DailyDead_cext),'r','linewidth',2);
m4=plot(Tm_ext,exp(DailyDead_mext),'b','linewidth',2);

c2.Color(4) = 0.25;
m2.Color(4) = 0.25;
c3.Color(4) = 0.25;
m3.Color(4) = 0.25;
c4.Color(4) = 0.25;
m4.Color(4) = 0.25;

xticks([60,91,121,152,182,213,244,274,305,335,366,397]);
xticklabels({'March','April','May','June','July','Aug','Sep','Oct',...
    'Nov','Dec','Jan 2021'})

fontname = 'Helvetica';
fontsize = 14;
set(gca,'XGrid','on',...
    'YGrid','on',...
    'XMinorGrid','off',...
    'YMinorGrid','off',...
    'YMinorTick','off',...
    'XMinorTick','off',...
    'YColor','k',...
    'XColor','k',...
    'LineWidth',1.5,...
    'TickLength',[0.02 0],...
    'Color','w',...
    'GridAlpha',0.05,...
    'GridAlphaMode','manual',...
    'GridColor','k',...
    'GridColorMode','manual',...
    'MinorGridAlpha',0.05,...
    'MinorGridAlphaMode','manual',...
    'MinorGridColor','k',...
    'MinorGridColorMode','manual',...
    'MinorGridLineStyle','-',...
    'FontName',fontname,...
    'FontSize',fontsize,...
    'Box','on')

set(gca, 'Layer','top')
set(gca,'yscale','log')
xlim([50,T_extrapolation])
ylim([10^-2,200])
set(gca,'Yscale','Log')
yticks([10^-2,10^-1,10^0,10^1,10^2,10^3])
yticklabels({'0.01','0.1','1','10','100','1000'})
ylabel('Daily deaths per million')

figure(2)
hold on
s1=plot(Tc,S_c);
S2=plot(Tm,S_m);

% ################### Plot extra england data ###################
if strcmp(str,'england')
    load('tableUK_2.mat')
    tableUK(:,1)=[];
    LDN_data=tableUK(2,:);
    LDNPop=8980000/1e6;
    LDN_data=LDN_data./LDNPop;
    tableHold=tableUK;
    tableHold(2,:)=[];
    ENPop=47020000/1e6;
    EN_data=sum(tableHold);
    EN_data=EN_data/ENPop;
    tldn=(t2(1):t2(1)+length(LDN_data)-1)-5;
    
    ind=find(tldn<=137);
    EN_data(ind)=[];
    LDN_data(ind)=[];
    tldn(ind)=[];
    
    figure(1)
    plot(tldn,exp(log(EN_data)+log(2.2)),'o','color',red_4,'markersize',4)
    plot(tldn,exp(log(LDN_data)+log(2.2)),'o','color',blue_4,'markersize',4);
    
    
end

% ############ No S/N #######################################
if NoS==1
    
    b1=1;
    
    y0=[N-1,1,0,0];
    t=linspace(ts,t1(1),1001);
    % Burn in
    options=odeset('event',@(t,y) StopEvent3(t,y,Pdead,data1));
    [T1cS,Y1cS,~,~]=ode45(@(t,y) SIRModel_TVB_NOSN(t,y,b1,gam,N,bi1,bf,bw,te),t,y0,options);
    y0=Y1cS(end,:);
    % t=t1;
    t=linspace(t1(1),TEnd_NoS,101);
    [TcS,YcS]=ode45(@(t,y) SIRModel_TVB_NOSN(t,y,b1,gam,N,bi1,bf,bw,te),t,y0);
    InitialDailyDead_cS=log(Y1cS(:,4)*Pdead);
    DailyDead_cS=log(YcS(:,4)*Pdead);
    
    
    y0=[N-1,1,0,0];
    t=linspace(ts-toff,t2(1),1001);
    % Burn in
    options=odeset('event',@(t,y) StopEvent3(t,y,Pdeadm,data2));
    [T1mS,Y1mS,~,~]=ode45(@(t,y) SIRModel_TVB_NOSN(t,y,b1,gam,N,bi2,bfm,bw,te-dt),t,y0,options);
    y0=Y1mS(end,:);
    % t=t2;
    t=linspace(t2(1),TEnd_NoS,101);
    [TmS,YmS]=ode45(@(t,y) SIRModel_TVB_NOSN(t,y,b1,gam,N,bi2,bfm,bw,te-dt),t,y0);
    InitialDailyDead_mS=log(Y1mS(:,4)*Pdeadm);
    DailyDead_mS=log(YmS(:,4)*Pdeadm);
    
    figure(1)
    hold on
    cNS1=plot(T1cS,exp(InitialDailyDead_cS),'r--','linewidth',1);
    mNS1=plot(T1mS,exp(InitialDailyDead_mS),'b--','linewidth',1);
    cNS2=plot(TcS,exp(DailyDead_cS),'r--','linewidth',1);
    mNS2=plot(TmS,exp(DailyDead_mS),'b--','linewidth',1);
    
    cNS1.Color(4) = 0.25;
    mNS1.Color(4) = 0.25;
    cNS2.Color(4) = 0.25;
    mNS2.Color(4) = 0.25;
    
end

% ####################### No Lockdown ##############################

if NoLockdown==1
    b1=1;
    
    y0=[N-1,1,0,0];
    t=linspace(ts,t1(1),1001);
    % Burn in
    options=odeset('event',@(t,y) StopEvent3(t,y,Pdead,data1));
    [T1cLD,Y1cLD,~,~]=ode45(@(t,y) SIRModel_TVB(t,y,b1,gam,N,bi1,bi1,bw,te),t,y0,options);
    y0=Y1cLD(end,:);
    % t=t1;
    t=linspace(t1(1),TEnd_NoS,101);
    [TcLD,YcLD]=ode45(@(t,y) SIRModel_TVB(t,y,b1,gam,N,bi1,bi1,bw,te),t,y0);
    InitialDailyDead_cLD=log(Y1cLD(:,4)*Pdead);
    DailyDead_cLD=log(YcLD(:,4)*Pdead);
    
    
    y0=[N-1,1,0,0];
    t=linspace(ts-toff,t2(1),1001);
    % Burn in
    options=odeset('event',@(t,y) StopEvent3(t,y,Pdeadm,data2));
    [T1mLD,Y1mLD,~,~]=ode45(@(t,y) SIRModel_TVB(t,y,b1,gam,N,bi2,bi2,bw,te-dt),t,y0,options);
    y0=Y1mLD(end,:);
    % t=t2;
    t=linspace(t2(1),TEnd_NoS,101);
    [TmLD,YmLD]=ode45(@(t,y) SIRModel_TVB(t,y,b1,gam,N,bi2,bi2,bw,te-dt),t,y0);
    InitialDailyDead_mLD=log(Y1mLD(:,4)*Pdeadm);
    DailyDead_mLD=log(YmLD(:,4)*Pdeadm);
    
    figure(1)
    hold on
    cNS1=plot(T1cLD,exp(InitialDailyDead_cLD),'r--','linewidth',1);
    mNS1=plot(T1mLD,exp(InitialDailyDead_mLD),'b--','linewidth',1);
    cNS2=plot(TcLD,exp(DailyDead_cLD),'r--','linewidth',1);
    mNS2=plot(TmLD,exp(DailyDead_mLD),'b--','linewidth',1);
    
    cNS1.Color(4) = 0.25;
    mNS1.Color(4) = 0.25;
    cNS2.Color(4) = 0.25;
    mNS2.Color(4) = 0.25;
    
end


if Relaxation==1
    
    bfm_R=bf_R.*betaratio;
    y0=Yc(end-back,:);
    t=linspace(ts_R,tldn(end),101);
    teR=t0_R;
    
    [TcR,YcR]=ode45(@(t,y) SIRModel_TVB(t,y,b1,gam,N,bf,bf_R,bw_R,teR),t,y0);
    DailyDead_cR=log(YcR(:,4)*Pdead);
    
    y0=Ym(end-back,:);
    t=linspace(ts_R,tldn(end),101);
    
    [TmR,YmR]=ode45(@(t,y) SIRModel_TVB(t,y,b1,gam,N,bfm,bfm_R,bw_R,teR),t,y0);
    DailyDead_mR=log(YmR(:,4)*Pdeadm);
    
    figure(1)
    hold on
    cF1=plot(TcR,exp(DailyDead_cR),'r--','linewidth',1);
    mF1=plot(TmR,exp(DailyDead_mR),'b--','linewidth',1);
    
    cF1.Color(4) = 0.25;
    mF1.Color(4) = 0.25;
end


if FullRelease==1
    b1=1;
    if Relaxation~=1
        y0=Yc(end,:);
        t=linspace(t1(end),T_extrapolation,101);
        teFR=t1(end)+10;
        bfFR=bf;
    else
        y0=YcR(end,:);
        t=linspace(tldn(end),T_extrapolation,101);
        teFR=tldn(end)+10;
        bfFR=bf_R;
    end
    
    [TcFR,YcFR]=ode45(@(t,y) SIRModel_TVB(t,y,b1,gam,N,bfFR,bi1,bw,teFR),t,y0);
    DailyDead_cFR=log(YcFR(:,4)*Pdead);
    
    if Relaxation~=1
        y0=Ym(end,:);
        t=linspace(t2(end),T_extrapolation,101);
        teFR=t1(end)+10;
        bfmFR=bfm;
    else
        y0=YmR(end,:);
        t=linspace(tldn(end),T_extrapolation,101);
        teFR=tldn(end)+10;
        bfmFR=bfm_R;
        
    end
    
    [TmFR,YmFR]=ode45(@(t,y) SIRModel_TVB(t,y,b1,gam,N,bfmFR,bi2,bw,teFR),t,y0);
    DailyDead_mFR=log(YmFR(:,4)*Pdeadm);
    
    figure(1)
    hold on
    cFR1=plot(TcFR,exp(DailyDead_cFR),'r--','linewidth',1);
    mFR1=plot(TmFR,exp(DailyDead_mFR),'b--','linewidth',1);
    
    cFR1.Color(4) = 0.25;
    mFR1.Color(4) = 0.25;
end

% bf_R=0.17; % New betaf for relaxed lockdown
% bw_R=10; % Width of relaxation
% t0_R=t1(end-5); % t0 of relaxation
% ts_R=t1(end-5);





